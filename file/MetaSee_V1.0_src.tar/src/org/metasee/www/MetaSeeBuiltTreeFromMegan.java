package org.metasee.www;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * built tree structure from file exported from Megan
 */
public class MetaSeeBuiltTreeFromMegan {
	/**
	 * add node to a tree
	 * @param filePath the path of input file exported from Megan
	 * @param rootNode the root node of tree
	 * 
	 */
	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){
		readTheNodeOfThisFile(filePath);
		deleteUnclassified(MetaSeeTree.rootNode);
		MetaSeeTree.rootNode.subNodes.remove(MetaSeeTree.rootNode.getSubNodeByName("unclassified"));
	}
	
	/**
	 * a recursion function to delete redundancy nodes of tree
	 * @param thisNode
	 */
	private static void deleteUnclassified(MetaSeeNode thisNode) {
		// TODO Auto-generated method stub
		if(thisNode.subNodes.size()==1 && thisNode.subNodes.get(0).name.equals("unclassified")){
			thisNode.subNodes.remove(thisNode.getSubNodeByName("unclassified"));
		}
		if(thisNode.subNodes.size()>0){
			
			int subNodeCountForDeleteUnclassified=0;
			if(thisNode.getSubNodeByName("unclassified") != null){
				for(int i : thisNode.getSubNodeByName("unclassified").counts){
					subNodeCountForDeleteUnclassified+=subNodeCountForDeleteUnclassified+i;
				}
			}
			if(subNodeCountForDeleteUnclassified==0){
				thisNode.subNodes.remove(thisNode.getSubNodeByName("unclassified"));
			}
			
			for(MetaSeeNode i:thisNode.subNodes){
				deleteUnclassified(i);
			}
		}
	}
	/**
	 * Begin to add node
	 * @param filePath the path of input file exported from Megan
	 */
	public static void readTheNodeOfThisFile(String filePath){
		BufferedReader plainFileBufferReader = null;
		String line;
		Pattern nodeNamePattern=Pattern.compile("([\\w\\W]+?);");//it is a node
		Pattern nodeCountPattern=Pattern.compile("\\s(\\d+)\\b");//it is a count of node
		Pattern dataSetLinePattern=Pattern.compile("^#Datasets");//this line is dataset information
		Pattern dataSetNamePattern=Pattern.compile("\\t([^\\t]+)");//it is a dataset name
		try {
			plainFileBufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			int datasetNumber=0;
			while((line=plainFileBufferReader.readLine())!=null){
				
				if(line.startsWith("root;Not assigned;") || line.startsWith("root;No hits;")){
					line="";
				}
				
				Matcher nodeNameMatcher=nodeNamePattern.matcher(line);
				Matcher dataSetLineMatcher=dataSetLinePattern.matcher(line);
				Matcher dataSetNameMatcher=dataSetNamePattern.matcher(line);
				while(dataSetLineMatcher.find()){
					while(dataSetNameMatcher.find()){
						MetaSeeTree.databaSetaName.add(dataSetNameMatcher.group(1));
						datasetNumber++;
					}
				}
				MetaSeeNode currentNode=MetaSeeTree.rootNode;
				Integer currentCount=0;

				while(MetaSeeTree.rootNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
					MetaSeeTree.rootNode.counts.add(0);
				}
				
				while(nodeNameMatcher.find()){
					if( currentNode.getSubNodeByName(nodeNameMatcher.group(1)) !=null){						
						currentNode=currentNode.getSubNodeByName(nodeNameMatcher.group(1));
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-datasetNumber)){
							currentNode.counts.add(0);
						}
																		
					}else{
						MetaSeeNode tempNode=new MetaSeeNode(nodeNameMatcher.group(1));
						tempNode.fatherNode=currentNode;
						currentNode.addSubNode(tempNode);
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-datasetNumber)){
							currentNode.counts.add(0);
						}
					}
					line=line.substring(line.indexOf(";")+1);
				}
				
				if( currentNode.getSubNodeByName("unclassified") !=null){						
					currentNode=currentNode.getSubNodeByName("unclassified");
					while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-datasetNumber)){
						currentNode.counts.add(0);
					}
																				
				}else{
					MetaSeeNode tempNode=new MetaSeeNode("unclassified");
					tempNode.fatherNode=currentNode;
					currentNode.addSubNode(tempNode);
					currentNode=tempNode;
					while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-datasetNumber)){
						currentNode.counts.add(0);
					}
				}
				
				int currentsize=(MetaSeeTree.databaSetaName.size()-datasetNumber)+1;

				Matcher nodeCountMatcher=nodeCountPattern.matcher(line);

				while(nodeCountMatcher.find()){
					currentCount=Integer.parseInt(nodeCountMatcher.group(1));
					MetaSeeNode fatherNodeForCount=currentNode;
					while(fatherNodeForCount != null){
						while(fatherNodeForCount.counts.size()<currentsize){
							fatherNodeForCount.counts.add(0);
						}

						if(fatherNodeForCount.counts.size()>=currentsize){
							fatherNodeForCount.counts.set((currentsize-1), (fatherNodeForCount.counts.get(currentsize-1)+currentCount));
						}
						fatherNodeForCount=fatherNodeForCount.fatherNode;
					}
					currentsize++;
				}
				
				currentsize=(MetaSeeTree.databaSetaName.size()-datasetNumber)+1;
				
			}
			datasetNumber=0;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
