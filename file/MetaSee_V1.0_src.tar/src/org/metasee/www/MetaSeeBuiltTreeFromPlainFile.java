package org.metasee.www;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * built tree structure from plainfile
 */
public class MetaSeeBuiltTreeFromPlainFile {
	/**
	 * add node to a tree
	 * @param filePath the path of input plainfile
	 * @param rootNode the root node of tree
	 * 
	 */
	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){
		File inPutFile=new File(filePath);
		MetaSeeTree.databaSetaName.add(inPutFile.getName());
		readTheNodeOfThisFile(filePath);
	}
	/**
	 * Begin to add node
	 * @param filePath the path of input plainfile
	 */
	public static void readTheNodeOfThisFile(String filePath){
		BufferedReader plainFileBufferReader = null;
		String line;
		Pattern nodeNamePattern=Pattern.compile("\\t(\\w+)");//it is a node
		Pattern nodeCountPattern=Pattern.compile("^([\\d.]+)");//it is a count of node
		try {
			plainFileBufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			while((line=plainFileBufferReader.readLine())!=null){
				Matcher nodeNameMatcher=nodeNamePattern.matcher(line);
				Matcher nodeCountMatcher=nodeCountPattern.matcher(line);
				MetaSeeNode currentNode=MetaSeeTree.rootNode;
				Integer currentCount=1;
				
				while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
					currentNode.counts.add(0);
				}
				
				while(nodeCountMatcher.find()){
					currentCount=Integer.parseInt(nodeCountMatcher.group(1));
					MetaSeeTree.rootNode.counts.set(MetaSeeTree.rootNode.counts.size()-1,(MetaSeeTree.rootNode.counts.get(MetaSeeTree.rootNode.counts.size()-1)+currentCount));
				}
				
				while(nodeNameMatcher.find()){
					if( currentNode.getSubNodeByName(nodeNameMatcher.group(1)) !=null){						
						currentNode=currentNode.getSubNodeByName(nodeNameMatcher.group(1));
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){
							currentNode.counts.add(0);
						}
						currentNode.counts.set((currentNode.counts.size()-1),(currentNode.counts.get(currentNode.counts.size()-1)+currentCount));
																		
					}else{
						MetaSeeNode tempNode=new MetaSeeNode(nodeNameMatcher.group(1));
						tempNode.fatherNode=currentNode;
						currentNode.addSubNode(tempNode);
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-1)){
							currentNode.counts.add(0);
						}
						currentNode.counts.add(currentCount);						
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
