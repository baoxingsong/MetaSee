package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * out put sample view
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */

public class MetaSeeKronaChart {
	public static MetaSeeTree tree=null;
	public static StringBuffer kronaChartStringBuffer=new StringBuffer();
	@SuppressWarnings("static-access")
	/**
	 * A new thread to output sample view
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	public void run(MetaSeeTree tree,String outPutDir){
		MetaSeeKronaChart.tree=tree;
		kronaChartStringBuffer.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><head><meta charset=\"utf-8\"/><script id=\"notfound\">window.onload=function(){document.body.innerHTML=\"Could not get javascript resources.\"}</script><script src=\"../lib/MetaSee_krona-2.0.js\"></script></head><body><img id=\"hiddenImage\" src=\"../skin/images/hidden.png\" style=\"display:none\"/><noscript>Javascript must be enabled to view this page.</noscript><div style=\"display:none\"><krona collapse=\"true\" key=\"true\"><attributes magnitude=\"count\"><list>members</list><attribute display=\"Count\" listAll=\"members\">count</attribute><attribute display=\"Unassigned\" listNode=\"members\">unassigned</attribute><attribute display=\"Avg. % Confidence\">score</attribute><attribute display=\"Rank\" mono=\"true\">rank</attribute></attributes><datasets>");//to be contieud
		for(int i=0;i<MetaSeeKronaChart.tree.databaSetaName.size();i++){
			kronaChartStringBuffer.append("<dataset>"+MetaSeeKronaChart.tree.databaSetaName.get(i)+"</dataset>");
		}
		kronaChartStringBuffer.append("</datasets><color attribute=\"score\" hueStart=\"0\" hueEnd=\"120\" valueStart=\"0\" valueEnd=\"100\" default=\"false\" ></color>");
		outPutKronaChart(tree.rootNode);
		kronaChartStringBuffer.append("</krona></div></body></html>");
		
		PrintStream kronaViewPrintStream;
		FileOutputStream kronaViewFileOutputStream=null;
		String fileName=outPutDir+File.separator+"smallSvg"+File.separator+"MetaSee_krona.html";
		File javascriptFile=new File(fileName);
		try {
			kronaViewFileOutputStream =new FileOutputStream(javascriptFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		kronaViewPrintStream=new PrintStream(kronaViewFileOutputStream);
		kronaViewPrintStream.print(kronaChartStringBuffer);
		
		
	}
	/**
	 * a recursion function to out sample view file and iterates the tree
	 * @param node a node of tree
	 */
	@SuppressWarnings("static-access")
	private static void outPutKronaChart(MetaSeeNode node) {
		kronaChartStringBuffer.append("<node name=\""+node.name+"\"><count>");//to be contieud
		for(int i=0;i<MetaSeeKronaChart.tree.databaSetaName.size();i++){
			kronaChartStringBuffer.append("<val>"+ node.counts.get(i) +"</val>");
		}
		kronaChartStringBuffer.append("</count>");
		if(node.hasSubNode()){
			kronaChartStringBuffer.append("");//to be contieud
			for(MetaSeeNode i : node.subNodes){
				outPutKronaChart(i);
			}
			kronaChartStringBuffer.append("");//to be contieud
		}
		kronaChartStringBuffer.append("</node>");//to be contieud
	}
}
