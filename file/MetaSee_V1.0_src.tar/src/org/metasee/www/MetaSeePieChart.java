package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
/**
 * out put the piechar of subsample view
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeePieChart {
	public static MetaSeeTree tree=null;
	/**
	 * A new thread to output piechat subsample view
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	public void run(MetaSeeTree tree,String outPutDir){
		MetaSeePieChart.tree=tree;
		drawSmallPie(tree.rootNode,outPutDir);
	}
	/**
	 * a recursion function to out all the piechat file and iterates the tree
	 * @param node a node of tree
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	private static void drawSmallPie(MetaSeeNode node,String outPutDir) {
		// TODO Auto-generated method stub
		
		StringBuffer smallPieChartStringBuffer=new StringBuffer();
		
		smallPieChartStringBuffer.append("<!DOCTYPE HTML>\n<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n");
		smallPieChartStringBuffer.append("<title>Pie Char</title>\n<link href=\"../skin/demo.css\" rel=\"stylesheet\" type=\"text/css\">\n<script type=\"text/javascript\" src=\"../lib/jquery.min.js\"></script>\n");
		smallPieChartStringBuffer.append("<script type=\"text/javascript\">\n var chart;\n$(document).ready(function() {\nchart = new Highcharts.Chart({\n");
		smallPieChartStringBuffer.append("chart: {\nrenderTo: 'container',\n plotBackgroundColor: null,\n plotBorderWidth: null,\n	plotShadow: false\n	},");
		smallPieChartStringBuffer.append("title: {\ntext: 'Count distribution of "+node.name+"'\n},\ntooltip: {\nformatter: function() {\nreturn '<b>'+ this.point.name +'</b>: '+ this.y;");
		smallPieChartStringBuffer.append("}\n},\nplotOptions: {\npie: {\nallowPointSelect: true,\ncursor: 'pointer',\ndataLabels: {\nenabled: true,\ncolor: '#000000',\n");
		smallPieChartStringBuffer.append("connectorColor: '#000000',\nformatter: function() {\nreturn '<b>'+ this.point.name +'</b>: '+ this.y;\n}}}},\n");
		smallPieChartStringBuffer.append("series: [{\ntype: 'pie',\nname: 'Browser share',\ndata: [\n");
		int SmapleSN=0;
		for(Integer i : node.counts){
			if(SmapleSN < MetaSeePieChart.tree.databaSetaName.size()-1){	
				smallPieChartStringBuffer.append("['"+MetaSeePieChart.tree.databaSetaName.get(SmapleSN)+"',   "+i+"],");

			}else{
				smallPieChartStringBuffer.append("['"+MetaSeePieChart.tree.databaSetaName.get(SmapleSN)+"',   "+i+"]");
			}
			SmapleSN++;
		}
		smallPieChartStringBuffer.append("]\n}]\n});\n});\n</script>\n");
		
		smallPieChartStringBuffer.append("<script type=\"text/javascript\">\n var chart;\n$(document).ready(function() {\nchart = new Highcharts.Chart({\n");
		smallPieChartStringBuffer.append("chart: {\nrenderTo: 'container2',\n plotBackgroundColor: null,\n plotBorderWidth: null,\n	plotShadow: false\n	},");
		smallPieChartStringBuffer.append("title: {\ntext: 'Percent distribution of "+node.name+"'\n},\ntooltip: {\nformatter: function() {\nreturn '<b>'+ this.point.name +'</b>: '+ this.y*100+\"%\";");
		smallPieChartStringBuffer.append("}\n},\nplotOptions: {\npie: {\nallowPointSelect: true,\ncursor: 'pointer',\ndataLabels: {\nenabled: true,\ncolor: '#000000',\n");
		smallPieChartStringBuffer.append("connectorColor: '#000000',\nformatter: function() {\nreturn '<b>'+ this.point.name +'</b>: '+ this.y*100+\"%\";\n}}}},\n");
		smallPieChartStringBuffer.append("series: [{\ntype: 'pie',\nname: 'Browser share',\ndata: [\n");
		SmapleSN=0;
		for(Integer i : node.counts){
			if(SmapleSN < MetaSeePieChart.tree.databaSetaName.size()-1){	
				smallPieChartStringBuffer.append("['"+MetaSeePieChart.tree.databaSetaName.get(SmapleSN)+"',   "+((double)i/MetaSeePieChart.tree.rootNode.counts.get(SmapleSN))+"],");

			}else{
				smallPieChartStringBuffer.append("['"+MetaSeePieChart.tree.databaSetaName.get(SmapleSN)+"',   "+((double)i/MetaSeePieChart.tree.rootNode.counts.get(SmapleSN))+"]");
			}
			SmapleSN++;
		}
		smallPieChartStringBuffer.append("]\n}]\n});\n});\n</script>\n");
		
		smallPieChartStringBuffer.append("</head>\n<body>\n<script type=\"text/javascript\" src=\"../lib/highcharts.js\"></script>\n<script type=\"text/javascript\" src=\"../lib/exporting.js\"></script>\n");
		smallPieChartStringBuffer.append("<div id=\"container\" style=\"width: 800px; height: 400px; margin: 0 auto\"></div>\n");
		smallPieChartStringBuffer.append("<p>&nbsp;</p><hr><p>&nbsp;</p>");
		smallPieChartStringBuffer.append("<div id=\"container2\" style=\"width: 800px; height: 400px; margin: 0 auto\"></div>\n");
		smallPieChartStringBuffer.append("<div class=\"buttons\">\n");
		smallPieChartStringBuffer.append("<a id=\"next-example\" title=\"Column Chart\" href=\""+node.ID+"column.html\">Bar Chart</a>\n</div>\n<br /><div align=\"center\">");
	
		smallPieChartStringBuffer.append("Sub-sample view:&nbsp;&nbsp;<a href=\""+tree.rootNode.ID+"pie.html\">"+tree.rootNode.name+"</a>");
		String tempForFatherNode=new String();
		String tempForFatherNodeAndLinkOutToNcbi=new String("Go to Taxonomy Browser:&nbsp;&nbsp;<a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ tree.rootNode.name +"\">"+tree.rootNode.name+"</a>");
		MetaSeeNode tempNodeForFaterNode=node;
		if(tempNodeForFaterNode.equals(tree.rootNode)){
			
		}else{
			while(!(tempNodeForFaterNode.equals(tree.rootNode))){
				tempForFatherNode=" -- <a href=\""+tempNodeForFaterNode.ID+"pie.html\">"+tempNodeForFaterNode.name+"</a>"+tempForFatherNode;
				tempForFatherNodeAndLinkOutToNcbi=new String("Go to Taxonomy Browser:&nbsp;&nbsp;<a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ tempNodeForFaterNode.name +"\">"+tempNodeForFaterNode.name+"</a>");
				tempNodeForFaterNode=tempNodeForFaterNode.fatherNode;
			}
		}
		smallPieChartStringBuffer.append(tempForFatherNode+"<p>&nbsp;</p><p>&nbsp;</p>"+tempForFatherNodeAndLinkOutToNcbi+"<p>&nbsp;</p><p>&nbsp;</p></body>\n</html>\n");
		
		
		PrintStream smallPie;
		FileOutputStream smallViewFileStream=null;
		String fileName=outPutDir+File.separator+"smallSvg"+File.separator+node.ID+"pie.html";
		File backupFile=new File(fileName);
		try {
			smallViewFileStream =new FileOutputStream(backupFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		smallPie=new PrintStream(smallViewFileStream);
		smallPie.print(smallPieChartStringBuffer);
		
		if(node.subNodes.size()>0){
			for(MetaSeeNode i:node.subNodes){
				drawSmallPie(i,outPutDir);
			}
		}
	}	
}
