package org.metasee.www;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 * copy library files to output path 
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeeLibCopy {

	static String url1 = "";  

	static String url2 = ""; 
	/**
	 * A new thread to copy files
	 * @param out  output path 
	 */
	public  void run(String out){
		url2=out;
		url1="forHtml";
		try {
			doFileCopy(url1,url2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * begain to copy library
	 * @param in the path of library files
	 * @param out the path of output
	 * @throws IOException
	 */
	public static void doFileCopy(String in,String out) throws IOException{
		

	    (new File(out)).mkdirs();  

	    File[] file = (new File(in)).listFiles();  
	    for (int i = 0; i < file.length; i++) {  
	        if (file[i].isFile()) {  

	            copyFile(file[i],new File(out+File.separator+file[i].getName()));  
	        }  
	        if (file[i].isDirectory()) {  

	            String sourceDir=in+File.separator+file[i].getName();  
	            String targetDir=out+File.separator+file[i].getName();  
	            copyDirectiory(sourceDir, targetDir);  
	        }  
	    }  
	}  
	/**
	 * copy files
	 * @param sourceFile the path of library files
	 * @param targetFile the path of output
	 * @throws IOException
	 */
	public static void copyFile(File sourceFile,File targetFile) throws IOException{  
	        FileInputStream input = new FileInputStream(sourceFile);  
	        BufferedInputStream inBuff=new BufferedInputStream(input);  
	        FileOutputStream output = new FileOutputStream(targetFile);  
	        BufferedOutputStream outBuff=new BufferedOutputStream(output);  
	        byte[] b = new byte[1024 * 5];  
	        int len;  
	        while ((len =inBuff.read(b)) != -1) {  
	            outBuff.write(b, 0, len);  
	        }  
	        outBuff.flush();  
	        inBuff.close();  
	        outBuff.close();  
	        output.close();  
	        input.close();  
	    }  
	/**
	 * copy directiory
	 * @param sourceDir the path of library files
	 * @param targetDir the path of output
	 * @throws IOException
	 */
    public static void copyDirectiory(String sourceDir, String targetDir)throws IOException {  
        (new File(targetDir)).mkdirs();  
        File[] file = (new File(sourceDir)).listFiles();  
        for (int i = 0; i < file.length; i++) {  
            if (file[i].isFile()) {  
            	File sourceFile=file[i];  
            	File targetFile=new 	File(new File(targetDir).getAbsolutePath() + File.separator+file[i].getName());  
                copyFile(sourceFile,targetFile);  
            }  
            if (file[i].isDirectory()) {  
                String dir1=sourceDir + "/" + file[i].getName();  
                String dir2=targetDir + "/"+ file[i].getName();  
                copyDirectiory(dir1, dir2);  
            }  
        }  
    }  
}
