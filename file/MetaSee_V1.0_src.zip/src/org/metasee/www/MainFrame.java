package org.metasee.www;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.filechooser.FileFilter;

/**the GUI of MetaSee*/
public class MainFrame implements ActionListener{

	private JFrame mainFrame = null;
	private JButton jb1 = null,jb2 = null,jb3 = null,jb4 = null;
	private JFileChooser jf = null,jf2 = null;
	private Container con = null;
	private ArrayList<File> fileList = null;
	private File toDir;
	private JPanel jp1 = null,jp2 = null;
	private JScrollPane jsp = null;
	private JLabel jl = null,jl2 = null,jl3 = null,jl4 = null;
	private JComboBox jcom = null;
	private int jpY = 50;
	/**constructed function to built the GUI*/
	public MainFrame(){
		mainFrame = new JFrame("MetaSee 1.0");
		fileList = new ArrayList<File>();
		jp1 = new JPanel();
		jp2 = new JPanel();
		jp2.setLayout(null);
		jp2.setSize(600,500);
		jsp = new JScrollPane(jp2);
		jp1.setBounds(5, 5,150,150);
		jsp.setBounds(175, 5,600,500);
		jp1.setLayout(new GridLayout(5,1,5,10));
		con = mainFrame.getContentPane();
		con.setLayout(null);
		jl = new JLabel("File format");
		jcom = new JComboBox(new Object[]{"metasee","parallelmeta","krona","plain","megan","mgrast"});
		jb1 = new JButton("input file ...");
		jb1.addActionListener(this);
		jb2 = new JButton("output folder ...");
		jb2.addActionListener(this);
		jb3 = new JButton("submit");
		jb3.addActionListener(this);
		//jb4 = new JButton("add");
		//jb4.setBounds(535, 400, 60, 30);
		//jb4.addActionListener(this);
		jl2 = new JLabel("Input file:");
		jl2.setBounds(10, 5, 200, 50);
		jl3 = new JLabel("Output folder:");
		jl3.setBounds(10, 450, 100, 50);
		jl4 = new JLabel();
		jl4.setBounds(115, 450, 300, 50);
		jl4.setForeground(Color.RED);
		//jp2.add(jb4);
		jp2.add(jl2);
		jp2.add(jl3);
		jp2.add(jl4);
		jf = new JFileChooser();
		jf.setMultiSelectionEnabled(true);
		//jf.setFileFilter(new MyFileFilter1());
		jf2 = new JFileChooser();
		jf2.setFileFilter(new MyFileFilter2());
		jf2.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		jp1.add(jl);
		jp1.add(jcom);
		jp1.add(jb1);
		jp1.add(jb2);
		jp1.add(jb3);
		con.add(jp1);
		con.add(jsp);
		mainFrame.setSize(800,600);
		mainFrame.setVisible(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==jb1 || e.getSource() == jb4){
			int result = jf.showOpenDialog(mainFrame);
			if(JFileChooser.APPROVE_OPTION == result){
				for(File f:jf.getSelectedFiles()){
					if(isContained(fileList,f))
						continue;
					fileList.add(f);
					JFileRecord jfr = new JFileRecord(f);
					jp2.add(jfr);
				}
				jp2.updateUI();
			}
		}else if(e.getSource()==jb2){
			int result = jf2.showOpenDialog(mainFrame);
			if(JFileChooser.APPROVE_OPTION == result){
				toDir = jf2.getSelectedFile();
				MetaSee.outPutDir = toDir.getAbsolutePath();
			}
			jl4.setText(toDir.getAbsolutePath());
		}else{
			//javax.swing.JOptionPane.showMessageDialog(null,fileList.size());
			if(fileList!=null &&toDir != null){
				MetaSee.inputFileFormat = (String)jcom.getSelectedItem();
				
				if(fileList.size()>1){
					MetaSee.produce(MetaSee.produceTree(new String(), objs2Strings(fileList.toArray()), objs2Strings(fileList.toArray())));
				}else{
					MetaSee.produce(MetaSee.produceTree(fileList.get(0).getAbsolutePath(), new String[0], new String[0]));
					//System.out.println(fileList.get(0).getAbsolutePath());
				}
			}else{
				JOptionPane.showMessageDialog(null, "Please select input file and output folder");
			}
			
		}
	}
	static boolean isContained(ArrayList<File> fileList,File f){
		Iterator<File> itr = fileList.iterator();
		while(itr.hasNext()){
			if(itr.next().getAbsolutePath().equals(f.getAbsolutePath()))
				return true;
		}
		return false;
	}
	static String[] objs2Strings(Object[] objs){
		File[] files = new File[objs.length];
		String[] fileNames = new String[objs.length];
		try{
			for(int i=0;i<objs.length;i++){
				files[i] = (File)objs[i];
				fileNames[i] = files[i].getAbsolutePath();
			}
		}catch(Exception ex){
			System.out.println("error");
			System.exit(1);
		}
		return fileNames;
	}
	class JFileRecord extends JPanel implements ActionListener{
		JLabel jl = null;
		JButton jb = null;
		File f = null;
		JFileRecord(File f){
			this.f = f;
			jl = new JLabel(f.getAbsolutePath());
			this.setLocation(this.location().x, jpY+5);
			jpY+=50;
			this.jl.setBounds((int)this.location().getX()+5, (int)this.location().getY(), 450, 35);
			jb = new JButton("delet");
			jb.addActionListener(this);
			this.jb.setBounds((int)this.location().getX()+470,(int)this.location().getY(),60,35);
			this.add(jl);
			this.add(jb);
			this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			this.setSize(600,50);
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			fileList.remove(f);
			jpY-=50;
			jp2.remove(this);
			jp2.updateUI();
		}
	}
	public static void main(String args[]){
		new MainFrame();
	}
}
class MyFileFilter1 extends FileFilter{

	@Override
	public boolean accept(File file) {
		// TODO Auto-generated method stub
		if(file.getName().endsWith(".xml") || file.isDirectory())
			return true;
		else
			return false;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "please select file end with xml";
	}
	
}
class MyFileFilter2 extends FileFilter{

	@Override
	public boolean accept(File f) {
		// TODO Auto-generated method stub
		if(f.isDirectory())
			return true;
		else
			return false;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "pelase seleted output folder";
	}
	
}