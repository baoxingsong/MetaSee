package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
/**
 * out put the phylogenetic view
 * @author SongBaoxing
 *
 */
public class PhylogeneticTreeHtml {
	public static MetaSeeTree tree=null;
	public static StringBuffer mainPieJavascriptFileStringBuffer=new StringBuffer();
	static List<StringBuffer> mainPieJavascriptArrayStringBuffer=new ArrayList<StringBuffer>();
	/**
	 * A new thread to output phylogenetic view
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	public void run(MetaSeeTree tree,String outPutDir){
		PhylogeneticTreeHtml.tree=tree;
		outPutPhylogeneticTreeHtml(tree.rootNode,outPutDir);
	}
	public static StringBuffer newickFileStringBuffer=new StringBuffer();
	/**
	 * output phylogenetic view
	 * @param node a node
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	private void outPutPhylogeneticTreeHtml(MetaSeeNode node,String outPutDir) {
		PrintStream phylogeneticTreeHtml;
		FileOutputStream phylogeneticTreeFileStream=null;		 
		File phylogeneticTreeFile=new File(outPutDir + File.separator +"smallSvg"+File.separator+"phylogeneticTree.html");
		try {
			phylogeneticTreeFileStream=new FileOutputStream(phylogeneticTreeFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		phylogeneticTreeHtml=new PrintStream(phylogeneticTreeFileStream);
		phylogeneticTreeHtml.print("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><!--[if IE]><script src=\"../lib/excanvasfotPhytree.js\"></script><![endif]--><title>Phylogenetic Tree</title><script language=\"JavaScript\" src=\"../lib/knhx.js\"></script><script language=\"JavaScript\" src=\"../lib/menu.js\"></script><script language=\"JavaScript\" src=\"../lib/canvastext.js\"></script><style type=\"text/css\"></style><script type=\"text/javascript\" src=\"../lib/yql\" id=\"script_id\"></script></head><body onLoad=\"knhx_init(&#39;canvas&#39;, &#39;nhx&#39;);\"><h1><input type=\"button\" id=\"toggle-usage\" value=\"Show Description\" onClick=\"toggle_usage();\"></h1><div id=\"usage\" style=\"display: none\"><h2>Requirements</h2><p>This page is known to be fully functional on Safari 5, Opera 10.5,Firefox 3.6 and Chrome. Image saving is not working in IE 8 due to thelack of <a href=\"http://en.wikipedia.org/wiki/Data_URI_scheme\">data URIscheme</a>; editing is not working in iOS 4. Nonetheless, on Windows,Safari, Opera, Chrome and Firefox are recommended anyway because the Javascript engine in IE 6/7/8 is far too slow and because `canvas' is not natively supported by IE 6/7/8. Rendering this tree on IE 8 is 100-fold slower than on Chrome/Opera/Safari.</p><h2>Usage</h2><ul>  <li>Clicking the white area in the canvas will bring up a popup menu, allowing you to:<ul><li><b>Draw</b>. Draw/redraw the tree with the current settings:<ul><li><b>Width</b>. The width of the image. For the rectangle view, the height of the image will be adjust automatically.	For the circular view, the height always equals the width.</li><li><b>Font size</b>. For the circular view, this is the maximum the font size. The actual font size	will be adjusted such that there is no overlaps between leaves.</li><li><b>Spacing</b>. The spacing between leaves. Not effective in the circular view.</li><li><b>2nd label</b>. The regular expression to match the secondary label of an internal node. Not effective in the circular view.</li><li><b>Pylogram</b>. Check this to ignore the branch lengths.</li><li><b>Circular</b>. Check this to switch to the circular layout.</li></ul></li><li><b>PNG</b>. Expore the tree picture as a PNG image.</li><li><b>Undo/Redo</b>. Undo the most recent editing. Only one undo is allowed.</li><li><b>Search</b>. Search for leaves matching a regular expression.</li></ul></li><li>Clicking a node will bring up a popup menu, allowing you to perform the following actions:<ul><li><b>Swap</b>. Click an internal node to swap its children.</li><li><b>Ladderize</b>. Click a node to sort the clade such that the	deeper leaves tend to be placed higher in the plot; in case of a tie, a leaf with lexicographically smaller names tends to be placed ahead.</li><li><b>Collapse</b>. Click a node to collapse/uncollapse all its descendants to one node.</li><li><b>Reroot</b>. Click a node to put the root in the middle of the edge between the node and its parent.</li><li><b>Move</b>. Click two nodes to prune the subtree descending from the first node and then regraft it to the edge between the second node and its parent.</li><li><b>Remove</b>. Click a node to delete it and all its descendants.</li><li><b>Multifurcate</b>. Click a node to multifurcate its parent node.</li><li><b>Highlight</b>. Click a node to highlight the entire clade. When a clade is highlighted, the Newick substring corresponding to the clade will be selected in the Input box. Given a huge tree, the selected text may not been seen in Opera, Chrom and	Safari. In this case, one may need to scroll back a little to see the selected text.</li></ul></li></ul><hr color=\"#cccccc\" noshade=\"\" size=\"1\"></div><p><span id=\"n_leaves\" style=\"color: gray;\"></span><span id=\"runtime\" style=\"color: gray;\"></span></p><br><textarea id=\"nhx\" style=\"visibility:hidden;\">");
		newickTree(PhylogeneticTreeHtml.tree.rootNode);
		newickFileStringBuffer.deleteCharAt(newickFileStringBuffer.length()-1);
		newickFileStringBuffer.append(";");
		phylogeneticTreeHtml.print(newickFileStringBuffer);
		phylogeneticTreeHtml.print("</textarea><P style=\"color:#FF0000\">Left click the bollow area to didplay the phylogenetic tree customly!</P><hr color=\"#cccccc\" noshade=\"\" size=\"1\"><div id=\"canvasContainer\" style=\"position: relative;\"><canvas id=\"canvas\" width=\"800\" height=\"432\"></canvas></div><div id=\"popdiv\" style=\"width: 150px; left: 399px; top: 232px; visibility: hidden;\"><h4>Menu</h4><a href=\"javascript:void(0);\" onClick=\"kn_actions.plot_str();\">Draw tree</a><a href=\"javascript:void(0);\" onClick=\"window.open(document.getElementById(&#39;canvas&#39;).toDataURL(&#39;image/png&#39;));\">Export to PNG</a><a href=\"javascript:void(0);\" onClick=\"kn_actions.undo_redo();\">Undo/Redo</a><a href=\"javascript:void(0);\" style=\"display: inline\" onClick=\"kn_search_leaf(kn_g_tree,document.getElementById(&#39;searchLeaf&#39;).value);kn_actions.plot();\">Search</a>: <input id=\"searchLeaf\" size=\"12\"><h4>Configurations</h4><table><tbody><tr><td>Width:</td><td><input size=\"5\" value=\"800\" onBlur=\"kn_g_conf.width=this.value;\"></td></tr><tr><td>Font size:</td><td><input size=\"5\" value=\"8\" onBlur=\"kn_g_conf.fontsize=this.value;\"></td></tr><tr><td>Spacing:</td><td><input size=\"5\" value=\"14\" onBlur=\"kn_g_conf.yskip=this.value;\"></td></tr><tr><td>2nd label:</td><td><input size=\"10\" value=\":B=([^:\\]]+)\" onBlur=\"kn_g_conf.regex=this.value;\"></td></tr><tr><td>Phylogram:</td><td><input type=\"checkbox\" checked=\"yes\" \"=\"\" onchange=\"kn_g_conf.is_real=this.checked;\"></td></tr><tr><td>Circular:</td><td><input type=\"checkbox\" \"=\"\" onchange=\"kn_g_conf.is_circular=this.checked;\"></td></tr></tbody></table><h4>Information</h4><table><tbody><tr><td># leaves:</td><td>28</td></tr><tr><td># nodes:</td><td>55</td></tr><tr><td>Run time:</td><td>0.008 sec</td></tr></tbody></table></div></body></html>");

	}
	/**
	 * built a StringBuffer of node information for output
	 * @param node a node
	 */
	public static void newickTree(MetaSeeNode node){
		if(node.subNodes.size()==0){
			newickFileStringBuffer.append(node.name+",");
		}
		if(node.hasSubNode()){
			newickFileStringBuffer.append("(");
			for(MetaSeeNode i:node.subNodes){
				newickTree(i);
			}
			newickFileStringBuffer.deleteCharAt(newickFileStringBuffer.length()-1);
			newickFileStringBuffer.append("),");
		}
	}
}
