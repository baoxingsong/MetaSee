package org.metasee.www;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
/**
 * output main framwork
 * @author SongBaoxing
 *
 */
public class MetaSeeFramworkPageHtml {
	
	public static StringBuffer mainPageHtmlContent =new StringBuffer();
	@SuppressWarnings("static-access")
	/**
	 *  A new thread to output framwork
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	public void run(MetaSeeTree tree, String outPutDir){
		mainPageHtmlContent.append(getHtmlPart("lib"+File.separator+"head.txt"));
		getOtherPartOfMainPageHtml(tree.rootNode);
		mainPageHtmlContent.append(getHtmlPart("lib"+File.separator+"root.txt"));

		PrintStream mainPageHtmlPrintStream;
		FileOutputStream mainPageHtmlOutPutFileStream=null;
		 
		File mainPageHtmlOutPutFile=new File(outPutDir + File.separator +"treeView.html");
		try {
			mainPageHtmlOutPutFileStream =new FileOutputStream(mainPageHtmlOutPutFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mainPageHtmlPrintStream=new PrintStream(mainPageHtmlOutPutFileStream);
		mainPageHtmlPrintStream.print(mainPageHtmlContent);
		//output to file end
	}
	/**
	 * a recursion function to collect the informations of nodes and iterates the tree
	 * @param node a node of tree
	 */
	public void getOtherPartOfMainPageHtml(MetaSeeNode node){
		mainPageHtmlContent.append("<li><a href=\"smallSvg/"+node.ID+"pie.html\" target=\"main\">"+node.name+"</a>");
		if(node.subNodes.size() >0){
			mainPageHtmlContent.append("<ul>");
			for(MetaSeeNode i:node.subNodes){
				getOtherPartOfMainPageHtml(i);
			}
			mainPageHtmlContent.append("</ul>");
		}
		mainPageHtmlContent.append("</li>");
		
	}
	/**
	 * add the content in plain file to StringBuffer for outputing
	 * @param file the file with plain format
	 * @return
	 */
	public static StringBuffer getHtmlPart(String file) {
		// TODO Auto-generated method stub
		BufferedReader htmlHeaderInput = null;
		StringBuffer htmlheaderString=new StringBuffer();
		String line;
		try {
			htmlHeaderInput = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			while((line=htmlHeaderInput.readLine())!=null){
				htmlheaderString.append(line+"\n");
			}
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return htmlheaderString;
		
	}

}