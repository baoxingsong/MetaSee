package org.metasee.www;



import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * built tree structure from Krona v2 file
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeeBuiltTreeFromKrona {
	/**
	 * add node to a tree
	 * @param filePath the path of input file with Krona v2 format
	 * @param rootNode the root node of tree
	 * 
	 */
	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){
		readTheNodeOfThisFile(filePath);
	}
	
	/**
	 * Begin to add node
	 * @param filePath the path of input file with Krona v2 format
	 */
	public static void readTheNodeOfThisFile(String filePath){
		
		/**use list to realize a stack to store the information of node, this a temporary List*/
		List<MetaSeeNode> databaseNode=new ArrayList<MetaSeeNode>();
		
		int metaSeeNodesn=0;//for which node is first, if it is first add the number to rootNode
		
		databaseNode.add(MetaSeeTree.rootNode);
		int datasetNumberOfThisFile=0;
		BufferedReader kronaInput = null;
		String line;
		MetaSeeNode currentNode=MetaSeeTree.rootNode;
		Pattern databasetPattern=Pattern.compile("<dataset>([\\w\\W]+?)</dataset>");//���ݲ��ֿ�ʼ
		Pattern nodeBegainPattern=Pattern.compile("<node name=\"([\\w\\W]+?)\">");//�ڵ㿪ʼ
		Pattern nodeEndPattern=Pattern.compile("(</node>)");//�ڵ����
		Pattern isCountPattern=Pattern.compile("<count>([\\w\\W]+?)</count>");//�ڵ������ݵĴ洢��
		Pattern countNumberPattern=Pattern.compile("<val>(\\d*)</val>");//�ڵ������ݵĶ�ȡ
		try {
			kronaInput = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			System.out.println("Cannot open the input file(s), check it please!");
			e.printStackTrace();
			System.exit(1);
		}
		try {
			
			while((line=kronaInput.readLine())!=null){
				Matcher databasetMatcher=databasetPattern.matcher(line);
				Matcher nodeBegainMatcher=nodeBegainPattern.matcher(line);
				Matcher nodeEndMatcher=nodeEndPattern.matcher(line);
				Matcher isCountMatcher=isCountPattern.matcher(line);

				while(databasetMatcher.find()){
					datasetNumberOfThisFile++;
					MetaSeeTree.databaSetaName.add(databasetMatcher.group(1));
				}
				while(nodeBegainMatcher.find()){
					metaSeeNodesn++;
					MetaSeeNode tempNode;
					tempNode=currentNode.getSubNodeByName(nodeBegainMatcher.group(1));
					if (tempNode==null){
						tempNode=new MetaSeeNode(nodeBegainMatcher.group(1));//�½��ڵ�
						if(databaseNode.size() >=1){//����ǰ�ڵ�����Ϊ��һ���ڵ���ӽڵ�
							MetaSeeNode tempNode2=databaseNode.get(databaseNode.size()-1);
							tempNode2.addSubNode(tempNode);
							tempNode.fatherNode=tempNode2;
						}
					}
					databaseNode.add(tempNode);//����ʱ��ջ���ݽṹ�д洢�½��Ľڵ�
					currentNode=tempNode;
				}
				
				while(nodeEndMatcher.find()){
					currentNode=currentNode.fatherNode;
					databaseNode.remove(databaseNode.size()-1);//��ʱlist��������ֵ�ǰ�ڵ��Ѿ��������򽫵�ǰ�ڵ�ӽڵ�list�г���
				}
				
				while(isCountMatcher.find()){
					Matcher countNumberMatcher=countNumberPattern.matcher(isCountMatcher.group(1));
					MetaSeeNode tempNode=databaseNode.get(databaseNode.size()-1);
					
					while(tempNode.counts.size()<(MetaSeeTree.databaSetaName.size()-datasetNumberOfThisFile)){
						tempNode.counts.add(0);
					}
					
					while(countNumberMatcher.find()){
						if(countNumberMatcher.group(1).length()==0){//���html�ļ��и�������ĿΪ�գ�����Ϊ����ط�Ӧ����0
							tempNode.counts.add(0);
						}else{
							tempNode.counts.add(new Integer(countNumberMatcher.group(1)));
						}
						if(metaSeeNodesn==1){
							MetaSeeTree.rootNode.counts.add(tempNode.counts.get(tempNode.counts.size()-1));
						}
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Something error happend when read the input file.");
			e.printStackTrace();
			System.exit(1);
		}
	}
}
