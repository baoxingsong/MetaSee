package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 * out put the global view
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeePillarGlobleView extends Thread{
	/**
	 * color of all small pillar
	 */
	static final String[] color={"fill:rgb(255,0,0)","fill:rgb(0,255,0)","fill:rgb(0,0,255)","fill:rgb(151,173,172)","fill:rgb(173,137,118)","fill:rgb(255,150,128)","fill:rgb(0,34,40)","fill:rgb(255,94,72)","fill:rgb(38,188,213)","fill:rgb(214,200,75)","fill:rgb(167,220,224)","fill:rgb(225,233,220)","fill:rgb(28,120,135)","fill:rgb(204,202,169)","fill:rgb(158,157,131)","fill:rgb(213,23,0)","fill:rgb(17,63,61)","fill:rgb(60,79,57)","fill:rgb(95,92,51)","fill:rgb(179,214,110)","fill:rgb(248,147,29)","fill:rgb(82,72,64)"};
	/**
	 * the height of every small bar chart, because the small chart will rotate 90 degrees so I call it width here.
	 */
	static double subGraphWidth=34;
	/**
	 *  the width of every small bar chart
	 */
	static int subGraphHeight;
	/**
	 *  the width of small pillar
	 */
	static int pillarHeight=5;
	/**
	 * the width of name of node
	 */
	static int widthOfText=135;
	List<String> databaSetaName=new ArrayList<String>();
	StringBuffer bigSvgOutput=new StringBuffer();
	
	MetaSeeNode rootNode=null;
	/**
	 * A new thread to output global
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	public void run(MetaSeeTree tree, String outPutDir){
		this.rootNode=tree.rootNode;
		this.databaSetaName=tree.databaSetaName;
		subGraphHeight=databaSetaName.size() * pillarHeight;
		subGraphHeight=subGraphHeight+widthOfText+10;
		//System.out.print(subGraphHeight);
		int bigSvgWidth=tree.maxDepthOfLeaf*(subGraphHeight)+520;
		double bigSvgHeight=tree.countOfLeaf*subGraphWidth+50;
		if(bigSvgHeight < 1200.0){
			bigSvgHeight=1200.0D;
		}
		HtmlIframe(bigSvgWidth,bigSvgHeight, outPutDir);
		
		bigSvgOutput.append("<?xml version=\"1.0\"?>\n <!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\" \"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n<svg xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:cc=\"http://creativecommons.org/ns#\" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\""+bigSvgWidth+"\" height=\""+bigSvgHeight+"\" id=\"svg2\" version=\"1.1\" sodipodi:docname=\"newdocument\"> <script xlink:href=\"../lib/SVGPan.js\"/> <defs id=\"defs4\"></defs> <metadata id=\"metadata7\"> <rdf:RDF> <cc:Work rdf:about=\"\"><dc:format>image/svg+xml</dc:format><dc:type rdf:resource=\"http://purl.org/dc/dcmitype/StillImage\" /><dc:title></dc:title></cc:Work> </rdf:RDF></metadata><g id=\"layer1\" transform=\"translate(0,0)\">");
		
		bigSvgOutput.append("<rect x=\""+(bigSvgWidth-300)+"\" y=\"100\" width=\"250\" height=\""+ ((databaSetaName.size()+1)*30) +"\" fill = \"none\" stroke=\"black\"/>");
		bigSvgOutput.append("<text x=\""+(bigSvgWidth-205)+"\" y=\"120\" font-family=\"Verdana\" font-size=\"16\" style=\"fill:rgb(0,0,0)\">Legend</text>");
		double matrixWidth=1.0;
		for(int i=0;i<databaSetaName.size();i++){
			if(databaSetaName.get(i).length()>17){
				matrixWidth=17/(double)databaSetaName.get(i).length();
			}
			bigSvgOutput.append("<a xlink:href=\"MetaSee_krona.html?dataset="+ i +"\">");
			bigSvgOutput.append("<rect x=\""+(bigSvgWidth-260)+"\" y=\""+((i*30)+134)+"\" width=\"8\" height=\"16\" style=\""+color[i]+"\"/>");
			bigSvgOutput.append("<text transform=\"matrix("+matrixWidth+" 0 0 1 "+(bigSvgWidth-250)+" "+((i*30)+150)+")\" font-family=\"Verdana\" font-size=\"16\" style=\""+color[i]+"\">"+ databaSetaName.get(i) +"</text>");
			bigSvgOutput.append("</a>");
		}
		
		this.PillarGlobleViewPrintOut(rootNode);
		bigSvgOutput.append("</g></svg>");
		
		PrintStream globleView;
		FileOutputStream globleViewFileStream=null;
		 
		File backupFile=new File(outPutDir + File.separator +"smallSvg"+File.separator+"globleView.svg");
		try {
			globleViewFileStream =new FileOutputStream(backupFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the Globle, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		globleView=new PrintStream(globleViewFileStream);
		globleView.print(bigSvgOutput);
		//output to file end
		
		
	}
	private void HtmlIframe(int width,double heigth, String outPutDir) {
		// TODO Auto-generated method stub
		StringBuffer htmlIframe=new StringBuffer();
		htmlIframe.append("<html><head><title>MetaSee Global View</title></head><body>");
		htmlIframe.append("<iframe id=\"svg\" name=\"svg\" src=\"globleView.svg\" frameborder=\"0\" scrolling=\"yes\"  width=\"100%\" height=\"100%\"></iframe></body></html>");
		
		PrintStream globleView;
		FileOutputStream globleViewFileStream=null;
		 
		File backupFile=new File(outPutDir + File.separator +"smallSvg"+File.separator+"globleView.html");
		try {
			globleViewFileStream =new FileOutputStream(backupFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the Globle, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		globleView=new PrintStream(globleViewFileStream);
		globleView.print(htmlIframe);
		
	}
	/**
	 * a recursion function to out put global view
	 * @param node a node of tree
	 * 
	 */
	public void PillarGlobleViewPrintOut(MetaSeeNode node){
		
		if(!(node.equals(rootNode))){
			if(node.fatherNode.subNodes.size()>1){
				bigSvgOutput.append("<line x1=\""+(node.positionX*subGraphHeight-0.75)+"\" y1=\""+ (node.positionY*subGraphWidth-3) +"\" x2=\""+(node.positionX*subGraphHeight+10)+"\" y2=\""+ (node.positionY*subGraphWidth-3) +"\" style=\"stroke:rgb(0,0,0);stroke-width:1.5\"/>\n");
			}else{
				bigSvgOutput.append("<line x1=\""+(node.positionX*subGraphHeight+5)+"\" y1=\""+ (node.positionY*subGraphWidth-3) +"\" x2=\""+(node.positionX*subGraphHeight+10)+"\" y2=\""+ (node.positionY*subGraphWidth-3) +"\" style=\"stroke:rgb(0,0,0);stroke-width:1.5\"/>\n");
			}
		}
		
		Double maxSample=0.0;//pick up the maximum one of this node from all the sample 

		for(int i=0;i<node.counts.size();i++){
			if((((double)node.counts.get(i))/((double)rootNode.counts.get(i))) >maxSample){
				maxSample=((double)node.counts.get(i))/((double)rootNode.counts.get(i));
			}
		}
		
		bigSvgOutput.append("<defs><g id=\""+ node.ID +"\" width=\""+subGraphWidth+"\" height=\""+subGraphHeight+"\" patternTransform=\"rotate(270)\" patternUnits=\"userSpaceOnUse\"  stroke=\"none\">\n");
		int SmapleSN=0;//record the SN current sample, for fill color, and calculate the location of every column
		for(Integer i : node.counts){
			double tempi=(double)i;
			tempi=tempi/((double)rootNode.counts.get(SmapleSN));
			double tempMaxSample=(double)maxSample;
			double subWidth=(tempi/tempMaxSample)*(subGraphWidth-4);
			int colorSN=SmapleSN;
			while(colorSN>21){
				colorSN=colorSN-22;
			}
			
			bigSvgOutput.append("<rect x=\"-1\" y=\""+(SmapleSN*pillarHeight)+"\" width=\""+subWidth+"\" height=\""+pillarHeight+"\" style=\""+color[colorSN]+";\"/>\n");
			bigSvgOutput.append("<line x1=\"-1\" y1=\""+ SmapleSN*pillarHeight +"\" x2=\"2\" y2=\""+SmapleSN*pillarHeight+"\" style=\"stroke:rgb(0,0,0);stroke-width:1\"/>\n");

			SmapleSN++;

		}
		bigSvgOutput.append("<line x1=\"-1\" y1=\""+ SmapleSN*pillarHeight +"\" x2=\"2\" y2=\""+SmapleSN*pillarHeight+"\" style=\"stroke:rgb(0,0,0);stroke-width:1\"/>");
		bigSvgOutput.append("<line x1=\"-1\" y1=\"-0.5\" x2=\"-1\" y2=\""+(databaSetaName.size() * pillarHeight+0.5)+"\" style=\"stroke:rgb(0,0,0);stroke-width:1\"/>");
		bigSvgOutput.append("</g></defs>\n<a xlink:href=\""+node.ID+"pie.html\">\n<use xlink:href=\"#"+node.ID+"\" x=\""+(node.positionX*subGraphHeight+widthOfText+2)+"\" y=\""+node.positionY*subGraphWidth+"\" transform=\"rotate(270,"+(node.positionX*subGraphHeight+widthOfText+2)+","+node.positionY*subGraphWidth+")\"/></a>");
		
		double matricTrans=1;
		if(node.name.length()>12){
			matricTrans=14/(double)node.name.length();
		}
		bigSvgOutput.append("<a xlink:href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ node.name +"\">");
		bigSvgOutput.append("<text transform=\"matrix(" + matricTrans + " 0 0 1 "+(node.positionX*subGraphHeight+15) + " " + node.positionY*subGraphWidth + ")\" font-family=\"Verdana\" font-size=\"12\" style=\"fill:rgb(0,0,0)\">"+ node.name +"</text>");
		bigSvgOutput.append("</a>");
		
		if(node.subNodes.size()>1){
			bigSvgOutput.append("<line x1=\""+ (node.positionX*subGraphHeight+widthOfText+5+databaSetaName.size() * pillarHeight)+"\" y1=\""+ (node.positionY*subGraphWidth-3) +"\" x2=\""+ (node.positionX*subGraphHeight+widthOfText+10+databaSetaName.size() * pillarHeight)+"\" y2=\""+ (node.positionY*subGraphWidth-3) +"\" style=\"stroke:rgb(0,0,0);stroke-width:1.5\"/>");
		
			bigSvgOutput.append("<line x1=\""+ (node.positionX*subGraphHeight+widthOfText+10+databaSetaName.size() * pillarHeight)+"\" y1=\""+ (node.getMaxVerticalBarPoint()*subGraphWidth-3) +"\" x2=\""+ (node.positionX*subGraphHeight+widthOfText+10+databaSetaName.size() * pillarHeight)+"\" y2=\""+ (node.getMinVerticalBarPoint()*subGraphWidth-3) +"\" style=\"stroke:rgb(0,0,0);stroke-width:1.5\"/>");
			
		}
		else if(node.subNodes.size()>0){
			bigSvgOutput.append("<line x1=\""+ (node.positionX*subGraphHeight+widthOfText+10+databaSetaName.size() * pillarHeight)+"\" y1=\""+ (node.positionY*subGraphWidth-3) +"\" x2=\""+ (node.positionX*subGraphHeight+widthOfText+15+databaSetaName.size() * pillarHeight)+"\" y2=\""+ (node.positionY*subGraphWidth-3) +"\" style=\"stroke:rgb(0,0,0);stroke-width:1.5\"/>");
		}
		
		if(node.subNodes.size()>0){
			for(MetaSeeNode i: node.subNodes){
				PillarGlobleViewPrintOut(i);
			}
		}
		
	}

}
