package org.metasee.www;

import java.util.ArrayList;
import java.util.List;
/**
 * the tree structure
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeeTree {
	/**
	 * Array to store the name of samples
	 */
	public static List<String> databaSetaName=new ArrayList<String>(); 	
	/**
	 * root node of tree
	 */
	public static MetaSeeNode rootNode=null;
	static int countOfLeaf=0;
	static int currentId=0;
	
	public static void main(String args[]){
		//new MetaSeeTree("metasee.xml");
	}
	/**
	 * accept input file and built tree structure
	 * @param inputFileFormat the format of input file
	 * @param filePath the path of input file
	 */
	public MetaSeeTree(String inputFileFormat,String ... filePath){
		rootNode=new MetaSeeNode("root");
		if(inputFileFormat.equalsIgnoreCase("metasee")){
			for (String i:filePath){
				MetaSeeBuiltTreeFromXml.MultipleFileTree(i,rootNode);
			}
		}else if(inputFileFormat.equalsIgnoreCase("parallelmeta")){
			for (String i:filePath){
				MetaSeeBuiltTreeFromParalleMeta.MultipleFileTree(i,rootNode);
			}
		}else if(inputFileFormat.equalsIgnoreCase("krona")){
			for (String i:filePath){
					MetaSeeBuiltTreeFromKrona.MultipleFileTree(i,rootNode);
			}
		}else if(inputFileFormat.equalsIgnoreCase("plain")){
			for (String i:filePath){
					MetaSeeBuiltTreeFromPlainFile.MultipleFileTree(i,rootNode);
			}
		}else if(inputFileFormat.equalsIgnoreCase("megan")){
			for (String i:filePath){
					MetaSeeBuiltTreeFromMegan.MultipleFileTree(i,rootNode);
			}
		}else if(inputFileFormat.equalsIgnoreCase("mgrast")){
			for (String i:filePath){
					MetaSeeBuiltTreeFromMgrast.MultipleFileTree(i,rootNode);
			}
		}else if (inputFileFormat.equalsIgnoreCase("matastorm")) {
		      for (String i : filePath)
		            MetaSeeBuiltTreeFromParalleMetaForMetasTorms.MultipleFileTree(i, rootNode);
		}else{
			System.out.println("error fileformat parameter, please check it");
			System.exit(1);
		}
		while(rootNode.subNodes.size()==1){
			rootNode=rootNode.subNodes.get(0);
			rootNode.fatherNode=null;
		}
		
		MetaSeeFirstErgodic(rootNode);
	}
	
	
	int snOfLeaf=1;
	int depthOfCurrentNode=1;
	static int maxDepthOfLeaf=0;
	

	List<List> nodeDepthArrayArray=new ArrayList<List>();
	/**
	 * ergodic this tree and record some information
	 * @param thisNode a node
	 */
	@SuppressWarnings({ "static-access", "unchecked" })
	public void MetaSeeFirstErgodic(MetaSeeNode thisNode){
		currentId++;
		thisNode.ID=currentId;
		
		while(thisNode.counts.size()<this.databaSetaName.size()){
			thisNode.counts.add(0);
		}
		
		thisNode.positionX=depthOfCurrentNode;
		if (maxDepthOfLeaf<depthOfCurrentNode){
			maxDepthOfLeaf=depthOfCurrentNode;
			nodeDepthArrayArray.add(new ArrayList<MetaSeeNode>());
		}
		nodeDepthArrayArray.get(depthOfCurrentNode-1).add(thisNode);
		if(thisNode.subNodes.size()>0){//this node is not a leaf
			depthOfCurrentNode++;
			for(MetaSeeNode i:thisNode.subNodes){
				MetaSeeFirstErgodic(i);
			}
			depthOfCurrentNode--;
			thisNode.positionY=(thisNode.getMaxVerticalBarPoint()+thisNode.getMinVerticalBarPoint())*0.5;
		}else{//this node is a leaf
			
			//count the leaf count of father node begain
			MetaSeeNode fatherNode=thisNode;
			if(fatherNode.fatherNode!=null){
				fatherNode=fatherNode.fatherNode;
				fatherNode.countOfLeaft++;
			}
			countOfLeaf++;
			//count the leaf count of father node end
			thisNode.positionY=snOfLeaf;
			snOfLeaf++;
		}
	}
	/**
	 * get maximum depth of this tree for the width of global view
	 * @param transedTree 
	 * @param depth current depth
	 * @param sampleId
	 * @return
	 */
	public static Integer getMaxmumOfThisDepthOfThisSampleId(MetaSeeTree transedTree, double depth, int sampleId){
		Integer maxmumOfThisDepthOfThisSampleId=0;
		int currentDepth=(int)depth;
		
		for(Object i : transedTree.nodeDepthArrayArray.get(currentDepth-1)){
			if(maxmumOfThisDepthOfThisSampleId<((MetaSeeNode)i).counts.get(sampleId)){
				maxmumOfThisDepthOfThisSampleId=((MetaSeeNode)i).counts.get(sampleId);
			}
		}
		//System.out.println(currentDepth);
		return maxmumOfThisDepthOfThisSampleId;
	}
	/**
	 * get minimum depth of this tree for the width of global view
	 * @param transedTree
	 * @param depth
	 * @param sampleId
	 * @return
	 */
	public static Integer getMinmumOfThisDepthOfThisSampleId(MetaSeeTree transedTree, double depth, int sampleId){
		Integer minmumOfThisDepthOfThisSampleId=Integer.MAX_VALUE;
		int currentDepth=(int)depth;
		for(Object i : transedTree.nodeDepthArrayArray.get(currentDepth-1)){
			if(minmumOfThisDepthOfThisSampleId>((MetaSeeNode)i).counts.get(sampleId)){
				minmumOfThisDepthOfThisSampleId=((MetaSeeNode)i).counts.get(sampleId);
			}
		}
		return minmumOfThisDepthOfThisSampleId;
	}
}
