package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * out put the file of unweighed phylogenetic tree with newick format
 * @author SongBaoxing
 *
 */

public class MetaSeeNewickPhylogeneticTree {
	public static MetaSeeTree tree=null;
	public static StringBuffer newickFileStringBuffer=new StringBuffer();
	/**
	 *  A new thread to output the file of unweighed phylogenetic tree with newick format
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	@SuppressWarnings("static-access")
	public void run(MetaSeeTree tree,String outPutDir){
		MetaSeeNewickPhylogeneticTree.tree=tree;
		outPutNewickTree(tree.rootNode);
		
		newickFileStringBuffer.deleteCharAt(newickFileStringBuffer.length()-1);
		newickFileStringBuffer.append(";");
	
		PrintStream newickPhylogeneticTree;
		FileOutputStream newickPhylogeneticTreeFileOutputStream=null;
		String fileName=outPutDir+File.separator+"smallSvg"+File.separator+"fakephylogenetictree.newick";
		File backupFile=new File(fileName);
		try {
			newickPhylogeneticTreeFileOutputStream =new FileOutputStream(backupFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the MetaSeeNewickPhylogeneticTree file, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		newickPhylogeneticTree=new PrintStream(newickPhylogeneticTreeFileOutputStream);
		newickPhylogeneticTree.print(newickFileStringBuffer);
	}
	/**
	 * a recursion function to iterates the tree
	 * @param node node of tree structure
	 */
	public static void outPutNewickTree(MetaSeeNode node){
		if(node.subNodes.size()==0){
			newickFileStringBuffer.append(node.name+",");
		}
		if(node.hasSubNode()){
			newickFileStringBuffer.append("(");
			for(MetaSeeNode i:node.subNodes){
				outPutNewickTree(i);
			}
			newickFileStringBuffer.deleteCharAt(newickFileStringBuffer.length()-1);
			newickFileStringBuffer.append("),");
		}
	}

}
