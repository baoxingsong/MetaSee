package org.metasee.www;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
/**
 * out put main control panel
 * @author SongBaoxing
 *
 */
public class MetaSeeMainPie {
	public static MetaSeeTree tree=null;
	public static StringBuffer mainPieJavascriptFileStringBuffer=new StringBuffer();
	static List<StringBuffer> mainPieJavascriptArrayStringBuffer=new ArrayList<StringBuffer>();

	/**
	 *  A new thread to output main control panel
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	public void run(MetaSeeTree tree,String outPutDir){
		MetaSeeMainPie.tree=tree;
		for(int i=0;i<MetaSeeMainPie.tree.databaSetaName.size();i++){
			mainPieJavascriptArrayStringBuffer.add(new StringBuffer(""));
		}
		
		mainPieJavascriptFileStringBuffer.append("var labelType, useGradients, nativeTextSupport, animate;\n(function() {\nvar ua = navigator.userAgent,\n");
		mainPieJavascriptFileStringBuffer.append("iStuff = ua.match(/iPhone/i) || ua.match(/iPad/i),\n typeOfCanvas = typeof HTMLCanvasElement,\nnativeCanvasSupport = (typeOfCanvas == 'object' || typeOfCanvas == 'function'),\n");
		mainPieJavascriptFileStringBuffer.append("textSupport = nativeCanvasSupport\n && (typeof document.createElement('canvas').getContext('2d').fillText == 'function');\nlabelType = (!nativeCanvasSupport || (textSupport && !iStuff))? 'Native' : 'HTML';\n");
		mainPieJavascriptFileStringBuffer.append("nativeTextSupport = labelType == 'Native';\nuseGradients = nativeCanvasSupport;\nanimate = !(iStuff || !nativeCanvasSupport);\n");
		mainPieJavascriptFileStringBuffer.append("})();\nvar Log = {\n elem: false,write: function(text){if (!this.elem)this.elem = document.getElementById('log');this.elem.innerHTML = text;this.elem.style.left = (500 - this.elem.offsetWidth / 2) + 'px';  }};");
		mainPieJavascriptFileStringBuffer.append("var depth="+ MetaSeeMainPie.tree.maxDepthOfLeaf +";");
		
		outPutMetaSeeMainPieJavascript(tree.rootNode);
		
		for(int i=0;i<MetaSeeMainPie.tree.databaSetaName.size();i++){
			mainPieJavascriptArrayStringBuffer.get(i).deleteCharAt(mainPieJavascriptArrayStringBuffer.get(i).length()-1);
			mainPieJavascriptArrayStringBuffer.get(i).deleteCharAt(mainPieJavascriptArrayStringBuffer.get(i).length()-1);
			mainPieJavascriptArrayStringBuffer.get(i).append(";");
			mainPieJavascriptFileStringBuffer.append("\n\nvar json"+(i+1)+" =");
			mainPieJavascriptFileStringBuffer.append(mainPieJavascriptArrayStringBuffer.get(i));
		}
		
		mainPieJavascriptFileStringBuffer.append("function mainPie() {document.getElementById(\"infovis\").innerHTML = \"\";if (document.getElementById(\"rb1\").checked) {drawMainPie(json1);}");
		for(int i=2;i<=MetaSeeMainPie.tree.databaSetaName.size();i++){
			mainPieJavascriptFileStringBuffer.append("else if (document.getElementById(\"rb"+i+"\").checked) {drawMainPie(json"+i+");}");
		}
		mainPieJavascriptFileStringBuffer.append("else {drawMainPie(json1);}}");
		mainPieJavascriptFileStringBuffer.append("function drawMainPie(json){var json=json;var sb = new $jit.Sunburst({injectInto: 'infovis',levelDistance: 390.0/depth,Node: {overridable: true,type: useGradients? 'gradient-multipie' : 'multipie'},Label: {type: labelType},NodeStyles: {enable: true,type: 'Native',stylesClick: {'color': '#33dddd'},stylesHover: {'color': '#");
		
		
		mainPieJavascriptFileStringBuffer.append("dd3333'}},Tips: {enable: true,onShow: function(tip, node) {var html = \"<div class=\\\"tip-title\\\">\" + node.name + \"</div>\"; var data = node.data;if(\"size\" in data) {html += \"<br /><b>Count:</b> \" + data.size;}tip.innerHTML = html;}},Events: {enable: true,onClick: function(node) {if(!node) return;var html = \"<h4>\" + node.name + \"</h4>\", data = node.data;if(\"size\" in data) {html += \"<br /><br /><b>Count:</b> \" + data.size;}if(\"description\" in data) {html += \"<br /><br /><b>ToolTips:</b><br /><pre>\" + data.description + \"</pre>\";}$jit.id('inner-details').innerHTML = html;sb.tips.hide();sb.rotate(node, animate? 'animate' : 'replot', {duration: 1000,transition: $jit.Trans.Quart.easeInOut});}},onCreateLabel: function(domElement, node){var labels = sb.config.Label.type,aw = node.getData('angularWidth');if (labels === 'HTML' && (node._depth < 2 || aw > 2000)) {domElement.innerHTML = node.name;} else if (labels === 'SVG' && (node._depth < 2 || aw > 2000)) { domElement.firstChild.appendChild(document.createTextNode(node.name));}},onPlaceLabel: function(domElement, node){var labels = sb.config.Label.type;if (labels === 'SVG') {var fch = domElement.firstChild;var style = fch.style;style.display = '';style.cursor = 'pointer';style.fontSize = \"0.8em\";fch.setAttribute('fill', \"#fff\");} else if (labels === 'HTML') {var style = domElement.style; style.display = '';style.cursor = 'pointer';style.fontSize = \"0.8em\";style.color = \"#ddd\";var left = parseInt(style.left);var w = domElement.offsetWidth; style.left = (left - w / 2) + 'px';}}});sb.loadJSON(json);sb.refresh();}");
		
		
		PrintStream mainPieJavascriptPrintStream;
		FileOutputStream mainPieJavascriptFileOutputStream=null;
		String fileName=outPutDir+File.separator+"smallSvg"+File.separator+"mainPie.js";
		File javascriptFile=new File(fileName);
		try {
			mainPieJavascriptFileOutputStream =new FileOutputStream(javascriptFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the javascript file of Main Pie Chart, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		mainPieJavascriptPrintStream=new PrintStream(mainPieJavascriptFileOutputStream);
		mainPieJavascriptPrintStream.print(mainPieJavascriptFileStringBuffer);
		
		mainPieHtmlPrint(outPutDir);
		
	}
	/**
	 * output javascript file of main control panel
	 * @param node a node of tree structure
	 */

	private void outPutMetaSeeMainPieJavascript(MetaSeeNode node) {//javascript file
		// TODO Auto-generated method stub
		
		String nodePath="<Strong>Classification:</Strong><br />"+tree.rootNode.name;
		String tempStringForFatherNode=new String();
		MetaSeeNode tempNodeForFaterNode=node;
		if(tempNodeForFaterNode.equals(tree.rootNode)){
			
		}else{
			while(!(tempNodeForFaterNode.equals(tree.rootNode))){
				tempStringForFatherNode="<br />"+tempNodeForFaterNode.name+tempStringForFatherNode;
				tempNodeForFaterNode=tempNodeForFaterNode.fatherNode;
			}
		}
		nodePath=nodePath+tempStringForFatherNode;
		nodePath=nodePath+"<br/><a href=\\\""+node.ID+"pie.html\\\" target=\\\"main\\\">go to Taxa view(pie chart)</a>"+"<br/><a href=\\\""+node.ID+"column.html\\\" target=\\\"main\\\">go to Taxa view(bar chart)</a>"+"<br/><a href=\\\"globleView.svg\\\" target=\\\"main\\\">go to Globle View</a> <br/><a href=\\\"phylogeneticTree.html\\\" target=\\\"main\\\">go to Phylogenetic View</a><br /><a href=\\\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ node.name +"\\\">"+"go to Taxonomy Browser" +"</a>";
		if(node.subNodes.size()>0){
			
			int countsSn=0;
			for(Integer i : node.counts){
				mainPieJavascriptArrayStringBuffer.get(countsSn).append("{\n\"children\": [\n");
				countsSn++;
			}
			
			for(MetaSeeNode i:node.subNodes){
				outPutMetaSeeMainPieJavascript(i);
			}
			
			countsSn=0;
			for(Integer i : node.counts){
				MetaSeeNode tempNodeForMainPieArray=node;
				String tempStringForMainPie=new String();
				while(tempNodeForMainPieArray.fatherNode!=null){
					tempNodeForMainPieArray=tempNodeForMainPieArray.fatherNode;
					tempStringForMainPie= tempNodeForMainPieArray.name+"/" + tempStringForMainPie;
				}
				
				int colorRed=0;
				int colorGreen=0;
				int maxMum=MetaSeeTree.getMaxmumOfThisDepthOfThisSampleId(MetaSeeMainPie.tree,node.positionX, countsSn);
				//System.out.println(maxMum);
				int minMum=MetaSeeTree.getMinmumOfThisDepthOfThisSampleId(MetaSeeMainPie.tree,node.positionX, countsSn);
				if(i==maxMum){
					colorRed=255;
					colorGreen=0;
				}else if(i==minMum){
					colorRed=0;
					colorGreen=255;
				}else{
					double y=((double)maxMum -(double)i)/((double)i-(double)minMum);
					colorRed=(int)(255.0/(y+1.0));
					colorGreen=255-colorRed;
					
				}
				String colorRedString=Integer.toHexString(colorRed);
				if(colorRedString.length()==1){
					colorRedString="0"+colorRedString;
				}
				
				String colorGreenString=Integer.toHexString(colorGreen);
				if(colorGreenString.length()==1){
					colorGreenString="0"+colorGreenString;
				}
				nodePath=nodePath+"<br/><a href=\\\"MetaSee_krona.html?node="+(node.ID-1)+"&dataset="+countsSn+"\\\" target=\\\"main\\\">go to Sample view</a>";
				
				mainPieJavascriptArrayStringBuffer.get(countsSn).deleteCharAt(mainPieJavascriptArrayStringBuffer.get(countsSn).length()-1);
				mainPieJavascriptArrayStringBuffer.get(countsSn).append("],\n\"data\": {\n\"description\":\""+nodePath+"\",\n\"$angularWidth\": 1000,\n\"days\": "+i+",\n\"$color\": \"#");
				mainPieJavascriptArrayStringBuffer.get(countsSn).append(colorRedString+colorGreenString+"00\",\n \"size\": "+i+"\n},\n");
				mainPieJavascriptArrayStringBuffer.get(countsSn).append("\"id\": \""+ tempStringForMainPie + node.name +"\", \n\"name\": \""+node.name+"\"\n},\n");
				countsSn++;
			}
		}else{
			int countsSn=0;
			if(node.countOfLeaft==0){
				for(Integer i : node.counts){
					MetaSeeNode tempNodeForMainPieArray=node;
					String tempStringForMainPie=new String();
					while(tempNodeForMainPieArray.fatherNode!=null){
						tempNodeForMainPieArray=tempNodeForMainPieArray.fatherNode;
						tempStringForMainPie= tempNodeForMainPieArray.name+"/" + tempStringForMainPie;
					}
					
					int colorRed=0;
					int colorGreen=0;
					int maxMum=MetaSeeTree.getMaxmumOfThisDepthOfThisSampleId(MetaSeeMainPie.tree,node.positionX, countsSn);
					//System.out.println(maxMum);
					int minMum=MetaSeeTree.getMinmumOfThisDepthOfThisSampleId(MetaSeeMainPie.tree,node.positionX, countsSn);
					if(i==maxMum){
						colorRed=255;
						colorGreen=0;
					}else if(i==minMum){
						colorRed=0;
						colorGreen=255;
					}else{
						double y=((double)maxMum -(double)i)/((double)i-(double)minMum);
						colorRed=(int)(255.0/(y+1.0));
						colorGreen=255-colorRed;
						
					}
					String colorRedString=Integer.toHexString(colorRed);
					if(colorRedString.length()==1){
						colorRedString="0"+colorRedString;
					}
					
					String colorGreenString=Integer.toHexString(colorGreen);
					if(colorGreenString.length()==1){
						colorGreenString="0"+colorGreenString;
					}
					
					nodePath=nodePath+"<br/><a href=\\\"MetaSee_krona.html?node="+(node.ID-1)+"&dataset="+countsSn+"\\\" target=\\\"main\\\">go to Sample view</a>";
					mainPieJavascriptArrayStringBuffer.get(countsSn).append("{\n\"children\": [],\n\"data\": {\n\"description\":\""+nodePath+"\",\n\"$angularWidth\": "+i+",\n\"days\": "+i+",\n\"$color\": \"#");
					mainPieJavascriptArrayStringBuffer.get(countsSn).append(colorRedString+colorGreenString+"00\",\n \"size\": "+i+"\n},\n");
					mainPieJavascriptArrayStringBuffer.get(countsSn).append("\"id\": \""+ tempStringForMainPie + node.name +"\", \n\"name\": \""+node.name+"\"\n},\n");
					countsSn++;
				}
			}
		}
	}
	/**
	 * output html part of main control panel
	 * @param outPutDir path of output
	 */
	@SuppressWarnings("static-access")
	public static void mainPieHtmlPrint(String outPutDir){//Html File
		PrintStream mainPieHtml;
		FileOutputStream mainPieFileStream=null;		 
		File mainPieFile=new File(outPutDir + File.separator +"smallSvg"+File.separator+"mainPie.html");
		try {
			mainPieFileStream=new FileOutputStream(mainPieFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the Main Pie Chart, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		mainPieHtml=new PrintStream(mainPieFileStream);
		mainPieHtml.print("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /><title>Main Pie Chart Of MetaSee</title><link type=\"text/css\" href=\"../skin/base.css\" rel=\"stylesheet\" /><!--[if IE]><script language=\"javascript\" type=\"text/javascript\" src=\"../lib/excanvas.js\"></script><![endif]--><script language=\"javascript\" type=\"text/javascript\" src=\"../lib/jit.js\"></script><script language=\"javascript\" type=\"text/javascript\" src=\"mainPie.js\"></script></head><script language=\"javascript\" type=\"text/javascript\"></script><body onload=\"mainPie();\"><div id=\"container\"><div id=\"center-container\"><div id=\"infovis\"></div></div><div id=\"right-container\"><div class=\"text\"><br /><b>Left click</b> to rotate the Sunburst to the selected node and see its details.<br/><input type=\"radio\" checked=\"true\" name=\"group\" id=\"rb1\" onClick=\"mainPie()\">");
		mainPieHtml.print(MetaSeeMainPie.tree.databaSetaName.get(0)+"<br />");
		for(int i=1;i<MetaSeeMainPie.tree.databaSetaName.size();i++){
			mainPieHtml.print("<input type=\"radio\" name=\"group\" id=\"rb"+(i+1)+"\" onClick=\"mainPie()\">"+MetaSeeMainPie.tree.databaSetaName.get(i)+"<br />");
		}
		mainPieHtml.print("</div><div id=\"inner-details\"></div></div><div id=\"log\"></div></div></body></html>");
	}

}
