package org.metasee.www;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
/**the main entrance of MetaSee
 * if parameters are provided, MetaSee will run on command line
 * else the GUI of MetaSee will run
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * @author SongBaoxing V1.0
 */
public class MetaSee {

	/* the target folder of output*/
	static String outPutDir=new String();
	/* the format of input file*/
	static String inputFileFormat=new String();
	/**
	 * @param -f the format of input file
	 * @param -i the input file(s)
	 * @param -o the path of output
	 * @param -h show help message
	 */
	public static void main(String[] args){
		if(args.length == 0){
			try {
				new MainFrame();
				return ;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			
		}
		
		////////////////////////////////////////////////////
		String singleFileName = null,multipleFileNames[] = null;
		Options options = new Options();
		//options.addOption("m",false,"multiple");
		options.addOption("i",true,"input file");
		options.addOption("o",true,"output dir");
		options.addOption("f",true,"inputFileFormat");
		options.addOption("h",false,"");
		options.addOption("H",false,"");
		options.addOption("HELP",false,"");
		options.addOption("Help",false,"");
		options.addOption("help",false,"");
		
		CommandLineParser parser = new PosixParser();
		CommandLine cmd=null;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Check the input parameter please, Or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		
		StringBuffer helpMessage=new StringBuffer("MetaSee 1.2\nWebsite:http://www.metasee.org\nArguments:\n");
		helpMessage.append("\t-i inputfile [inputfile ...] input file\n	   The path of input file, multiple file accept.\n");
		helpMessage.append("\t-o outpur path\n	   To appoint the result output path\n");
		helpMessage.append("\t-f the format of input file\n");
		helpMessage.append("\t   \"metasee\" for metasee xml\n");
		helpMessage.append("\t   \"parallelmeta\" for the result of parallelmeta\n");
		helpMessage.append("\t   \"krona\" for a krona html file\n");
		helpMessage.append("\t   \"plain\" for a plain text file\n");
		helpMessage.append("\t   \"megan\" for a megan result file\n");
		helpMessage.append("\t   \"mgrast\" for a mgrast sample result file\n");
		helpMessage.append("\t-h show this message");
		
		if(cmd.hasOption("h") || cmd.hasOption("H") || cmd.hasOption("Help") || cmd.hasOption("HELP") || cmd.hasOption("help")){
			System.out.println(helpMessage);
			System.exit(0);
		}
		
		if(!cmd.hasOption("i") || !cmd.hasOption("o") || !cmd.hasOption("f")){
			System.out.println("Error parameter!!!\n"+helpMessage);
			System.exit(1);
		}
		singleFileName = cmd.getOptionValue("i");
		String[] elseFile = cmd.getArgs();
		if(elseFile.length != 0){
			multipleFileNames = new String[elseFile.length+1];
			multipleFileNames[0] = singleFileName;
			for(int i=0;i<elseFile.length;i++){
				multipleFileNames[i+1] = elseFile[i];
			}
		}
		outPutDir = cmd.getOptionValue("o");
		inputFileFormat = cmd.getOptionValue("f").toLowerCase();
		//////////////////////////////////////////////
		
		(new File(outPutDir)).mkdirs(); 
		(new File(outPutDir + File.separator +"smallSvg")).mkdirs();
		
		MetaSeeTree tree = produceTree(singleFileName,elseFile,multipleFileNames);
		produce(tree);
		
	}
	/**
	 * built a tree structure in memory
	 * @param singleFileName if there is only one input file, this is the file name
	 * @param elseFile to judge how many input file
	 * @param multipleFileNames if there are more than one input file, this is the file name
	 * @return a tree structure
	 */
	public static MetaSeeTree produceTree(String singleFileName,String[] elseFile,String[] multipleFileNames){
		MetaSeeTree tree=null;//new MetaSeeTree("metasee.xml");
		if(elseFile.length == 0){
			tree=new MetaSeeTree(inputFileFormat,singleFileName);
		}
		else{
			tree=new MetaSeeTree(inputFileFormat,multipleFileNames);
		}
		return tree;
	}
	/**
	 * output a variety of views
	 * @param a the tree structure

	 */
	public static void produce(MetaSeeTree tree){
		if(!new File(outPutDir+File.separator+"smallSvg").exists()){
			new File(outPutDir+File.separator+"smallSvg").mkdirs();
		}
		MetaSeePillarGlobleView svgGlobleView=new MetaSeePillarGlobleView();
		svgGlobleView.run(tree,outPutDir);
		MetaSeeFramworkPageHtml mainPageHtml=new MetaSeeFramworkPageHtml();
		mainPageHtml.run(tree,outPutDir);
		MetaSeePieChart smallPieChart=new MetaSeePieChart();
		smallPieChart.run(tree,outPutDir);
		MetaSeeColumnChart smallColumnChart=new MetaSeeColumnChart();
		smallColumnChart.run(tree,outPutDir);
		MetaSeeNewickPhylogeneticTree newickFile=new MetaSeeNewickPhylogeneticTree();
		newickFile.run(tree,outPutDir);
		MetaSeeMainPie mainPie=new MetaSeeMainPie();
		mainPie.run(tree,outPutDir);
		MetaSeeKronaChart kronaChart=new MetaSeeKronaChart();
		kronaChart.run(tree,outPutDir);
		MetaSeeLibCopy libFileCopy=new MetaSeeLibCopy();
		libFileCopy.run(outPutDir);
		PhylogeneticTreeHtml phylogeneticTreeHtml=new PhylogeneticTreeHtml();
		phylogeneticTreeHtml.run(tree,outPutDir);
		ZipFile zipFile= new ZipFile();
		zipFile.run(outPutDir);
		System.out.print("succeed");
		MetaSeeTree.maxDepthOfLeaf = 0;
		MetaSeeTree.databaSetaName=new ArrayList<String>();
		MetaSeeTree.rootNode=null;
		MetaSeeTree.countOfLeaf=0;
		MetaSeeTree.currentId=0;
		
		MetaSeeColumnChart.tree=null;
		MetaSeeKronaChart.tree=null;
		
		MetaSeeLibCopy.url1="";
		MetaSeeLibCopy.url2="";
		
		MetaSeeFramworkPageHtml.mainPageHtmlContent=new StringBuffer();
		
		MetaSeeMainPie.tree=null;
		MetaSeeMainPie.mainPieJavascriptFileStringBuffer=new StringBuffer();
		MetaSeeMainPie.mainPieJavascriptArrayStringBuffer=new ArrayList<StringBuffer>();
		
		MetaSeeNewickPhylogeneticTree.tree=null;
		MetaSeeNewickPhylogeneticTree.newickFileStringBuffer=new StringBuffer();
		
		MetaSeePieChart.tree=null;
		
		MetaSeePillarGlobleView.subGraphWidth=34;
		MetaSeePillarGlobleView.subGraphHeight=0;
		MetaSeePillarGlobleView.pillarHeight=5;
		MetaSeePillarGlobleView.widthOfText=135;
		
		PhylogeneticTreeHtml.tree=null;
		PhylogeneticTreeHtml.mainPieJavascriptFileStringBuffer=new StringBuffer();
		PhylogeneticTreeHtml.mainPieJavascriptArrayStringBuffer=new ArrayList<StringBuffer>();
		PhylogeneticTreeHtml.newickFileStringBuffer=new StringBuffer();
	}
}
