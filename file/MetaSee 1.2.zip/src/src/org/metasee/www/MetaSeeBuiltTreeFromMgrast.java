package org.metasee.www;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * built tree structure from file exported from Mg-Rast
 */
public class MetaSeeBuiltTreeFromMgrast {
	/**
	 * add node to a tree
	 * @param filePath the path of input file exported from Mg-Rast
	 * @param rootNode the root node of tree
	 */
	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){
		readTheNodeOfThisFile(filePath);
	}
	/**
	 * Begin to add node
	 * @param filePath the path of input file exported from Mg-Rast
	 */
	public static void readTheNodeOfThisFile(String filePath){
		BufferedReader plainFileBufferReader = null;
		String line;
		MetaSeeNode currentNode=MetaSeeTree.rootNode;
		Pattern nodeNamePattern=Pattern.compile("^(.*?)\\t(.*?)\\t(.*?)\\t(.*?)\\t(.*?)\\t");//it is a node
		Pattern nodeCountPattern=Pattern.compile("\\s(\\d+)\\s*$");//it is a count of node
		Pattern datasetNamePattern=Pattern.compile("^([\\d.]+)");//it is a datasetName of node
		int numberForDatasetName=0;
		int currentCount=0;
		try {
			plainFileBufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			System.out.println("Cannot open the input file(s), check it please!");
			e.printStackTrace();
			System.exit(1);
		}
		try {
			while((line=plainFileBufferReader.readLine())!=null){
				line=line.replaceAll("\\&", "and");
				line=line.replaceAll("\"", "");
				line=line.replaceAll("\'", "");
				Matcher nodeNameMatcher=nodeNamePattern.matcher(line);
				Matcher nodeCountMatcher=nodeCountPattern.matcher(line);
				Matcher datasetNameMatcher=datasetNamePattern.matcher(line);
				
				if(datasetNameMatcher.find()){
					if(numberForDatasetName==0){
						MetaSeeTree.databaSetaName.add(datasetNameMatcher.group(1));
						numberForDatasetName++;
					}
				}
				
				while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
					currentNode.counts.add(0);
				}
				
				if(nodeCountMatcher.find()){
					currentCount=Integer.parseInt(nodeCountMatcher.group(1));
				}
				
				if(numberForDatasetName > 0){
					while(nodeNameMatcher.find()){
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
							currentNode.counts.add(0);
						}
						currentNode.counts.set(currentNode.counts.size()-1, currentNode.counts.get(currentNode.counts.size()-1)+currentCount);
						
						MetaSeeNode tempNode;
						
						tempNode=currentNode.getSubNodeByName(nodeNameMatcher.group(2));
						if (tempNode==null){
							tempNode=new MetaSeeNode(nodeNameMatcher.group(2));//
							currentNode.addSubNode(tempNode);
							tempNode.fatherNode=currentNode;
						}
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
							currentNode.counts.add(0);
						}
						currentNode.counts.set(currentNode.counts.size()-1, currentNode.counts.get(currentNode.counts.size()-1)+currentCount);

						tempNode=currentNode.getSubNodeByName(nodeNameMatcher.group(3));
						if (tempNode==null){
							tempNode=new MetaSeeNode(nodeNameMatcher.group(3));//
							currentNode.addSubNode(tempNode);
							tempNode.fatherNode=currentNode;
						}
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
							currentNode.counts.add(0);
						}
						currentNode.counts.set(currentNode.counts.size()-1, currentNode.counts.get(currentNode.counts.size()-1)+currentCount);
						
						tempNode=currentNode.getSubNodeByName(nodeNameMatcher.group(4));
						if (tempNode==null){
							tempNode=new MetaSeeNode(nodeNameMatcher.group(4));//
							currentNode.addSubNode(tempNode);
							tempNode.fatherNode=currentNode;
						}
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
							currentNode.counts.add(0);
						}
						currentNode.counts.set(currentNode.counts.size()-1, currentNode.counts.get(currentNode.counts.size()-1)+currentCount);

						tempNode=currentNode.getSubNodeByName(nodeNameMatcher.group(5));
						if (tempNode==null){
							tempNode=new MetaSeeNode(nodeNameMatcher.group(5));//
							currentNode.addSubNode(tempNode);
							tempNode.fatherNode=currentNode;
						}
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
							currentNode.counts.add(0);
						}
						currentNode.counts.set(currentNode.counts.size()-1, currentNode.counts.get(currentNode.counts.size()-1)+currentCount);
					}
				}
				
				currentNode=MetaSeeTree.rootNode;
			}
			
			numberForDatasetName=0;
		} catch (IOException e) {
			System.out.println("Something error happend when read the input file.");
			e.printStackTrace();
			System.exit(1);
		}
	}

}
