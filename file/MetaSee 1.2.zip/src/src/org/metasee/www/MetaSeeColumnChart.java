package org.metasee.www;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
/**
 * out put the barchar of subsample view
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 */
public class MetaSeeColumnChart {

	public static MetaSeeTree tree=null;

	/**
	 * A new thread to output barchat subsample view
	 * @param tree a tree structure
	 * @param outPutDir the path of output
	 */
	public void run(MetaSeeTree tree,String outPutDir){
		MetaSeeColumnChart.tree=tree;
		drawSmallColumn(tree.rootNode,outPutDir);
	}
	/**
	 * a recursion function to out put all the barchat file and iterates the tree
	 * @param node a node of tree
	 * @param outPutDir the path of output
	 */

	private static void drawSmallColumn(MetaSeeNode node,String outPutDir) {
		// TODO Auto-generated method stub
		StringBuffer smallColumnChartStringBuffer=new StringBuffer();
		
		smallColumnChartStringBuffer.append("<!DOCTYPE HTML>\n<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n");
		smallColumnChartStringBuffer.append("<title>Bar Char</title>\n<link href=\"../skin/demo.css\" rel=\"stylesheet\" type=\"text/css\">\n<script type=\"text/javascript\" src=\"../lib/jquery.min.js\"></script>\n");
		
		smallColumnChartStringBuffer.append("<script type=\"text/javascript\">\n var chart;\n$(document).ready(function() {\nchart = new Highcharts.Chart({\n chart: { \n");
		smallColumnChartStringBuffer.append("renderTo: 'container',\ndefaultSeriesType: 'column',\nmargin: [ 50, 50, 100, 80]\n},\ntitle: {\ntext: 'Count distribution of "+node.name+"'\n},\nxAxis: {\ncategories: [\n");
				StringBuffer smallColumnNameOutput=new StringBuffer();
		StringBuffer smallColumnDataOutput=new StringBuffer();
		int SmapleSN=0;
		for(Integer i : node.counts){
			if(SmapleSN < MetaSeeColumnChart.tree.databaSetaName.size()-1){	
				
				smallColumnNameOutput.append("'"+MetaSeeColumnChart.tree.databaSetaName.get(SmapleSN)+"',");
				smallColumnDataOutput.append(i+",");
			}else{
				smallColumnNameOutput.append("'"+MetaSeeColumnChart.tree.databaSetaName.get(SmapleSN)+"'");
				smallColumnDataOutput.append(i);
			}
			
			SmapleSN++;
		}		
		smallColumnChartStringBuffer.append(smallColumnNameOutput);
		smallColumnChartStringBuffer.append("],\n labels: {\n rotation: -45,\n align: 'right', \n style: {\n font: 'normal 13px Verdana, sans-serif'\n");
		smallColumnChartStringBuffer.append("}\n}\n},\nyAxis: {\nmin: 0,\ntitle: {\ntext: ''\n}\n},\nlegend: {\nenabled: false\n},\n");
		smallColumnChartStringBuffer.append("tooltip: {\n formatter: function() {\n return '<b>'+ this.x +'</b><br/>'+ Highcharts.numberFormat(this.y, 1); +\n '';\n } \n }, \n series: [{ \n name: 'Population',\n data: [\n");
		smallColumnChartStringBuffer.append(smallColumnDataOutput);
		smallColumnChartStringBuffer.append("],\n dataLabels: {\n enabled: true,\n rotation: -90,\n color: '#FFFFFF',\n align: 'right',\nx: -3,\n y: 10,\n formatter: function() {\n return this.y; \n }, \n style: { \n font: 'normal 13px Verdana, sans-serif' \n } \n } \n }] \n }); \n }); \n </script> \n ");
		
		smallColumnChartStringBuffer.append("<script type=\"text/javascript\">\n var chart;\n$(document).ready(function() {\nchart = new Highcharts.Chart({\n chart: { \n");
		smallColumnChartStringBuffer.append("renderTo: 'container2',\ndefaultSeriesType: 'column',\nmargin: [ 50, 50, 100, 80]\n},\ntitle: {\ntext: 'Distribution distribution of "+node.name+"'\n},\nxAxis: {\ncategories: [\n");
		smallColumnNameOutput=new StringBuffer();
		smallColumnDataOutput=new StringBuffer();
		SmapleSN=0;
		for(Integer i : node.counts){
			if(SmapleSN < MetaSeeColumnChart.tree.databaSetaName.size()-1){	
				
				smallColumnNameOutput.append("'"+MetaSeeColumnChart.tree.databaSetaName.get(SmapleSN)+"',");
				smallColumnDataOutput.append(((double)i/MetaSeePieChart.tree.rootNode.counts.get(SmapleSN))+",");
			}else{
				smallColumnNameOutput.append("'"+MetaSeeColumnChart.tree.databaSetaName.get(SmapleSN)+"'");
				smallColumnDataOutput.append(((double)i/MetaSeePieChart.tree.rootNode.counts.get(SmapleSN)));
			}
			
			SmapleSN++;
		}		
		smallColumnChartStringBuffer.append(smallColumnNameOutput);
		smallColumnChartStringBuffer.append("],\n labels: {\n rotation: -45,\n align: 'right', \n style: {\n font: 'normal 13px Verdana, sans-serif'\n");
		smallColumnChartStringBuffer.append("}\n}\n},\nyAxis: {\nmin: 0,\ntitle: {\ntext: ''\n}\n},\nlegend: {\nenabled: false\n},\n");
		smallColumnChartStringBuffer.append("tooltip: {\n formatter: function() {\n return '<b>'+ this.x +'</b><br/>'+ this.y*100+\"%\" +\n '';\n } \n }, \n series: [{ \n name: 'Population',\n data: [\n");
		smallColumnChartStringBuffer.append(smallColumnDataOutput);
		smallColumnChartStringBuffer.append("],\n dataLabels: {\n enabled: true,\n rotation: -90,\n color: '#FFFFFF',\n align: 'right',\nx: -3,\n y: 10,\n formatter: function() {\n return this.y*100+\"%\"; \n }, \n style: { \n font: 'normal 13px Verdana, sans-serif' \n } \n } \n }] \n }); \n }); \n </script> \n ");
		
		smallColumnChartStringBuffer.append("</head>\n <body> \n <script type=\"text/javascript\" src=\"../lib/highcharts.js\"></script>\n <script type=\"text/javascript\" src=\"../lib/exporting.js\"></script> \n");
		smallColumnChartStringBuffer.append("<div id=\"container\" style=\"width: 800px; height: 400px; margin: 0 auto\"></div>");
		smallColumnChartStringBuffer.append("<p>&nbsp;</p><hr><p>&nbsp;</p>");
		smallColumnChartStringBuffer.append("<div id=\"container2\" style=\"width: 800px; height: 400px; margin: 0 auto\"></div>");
		smallColumnChartStringBuffer.append("\n<div class=\"buttons\">\n");
		smallColumnChartStringBuffer.append("<a id=\"next-example\" title=\"Column Chart\" href=\""+node.ID+"pie.html\">Pie Chart</a>\n</div>\n<br />\n<div align=\"center\">");
		smallColumnChartStringBuffer.append("Taxa view:&nbsp;&nbsp;<a href=\""+tree.rootNode.ID+"column.html\">"+MetaSeeColumnChart.tree.rootNode.name+"</a>");
				
		String tempForFatherNode=new String();
		
		String tempForFatherNodeAndLinkOutToNcbi=new String("Go to Taxonomy Browser:&nbsp;&nbsp;<a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ tree.rootNode.name +"\">"+tree.rootNode.name+"</a>");
		
		MetaSeeNode tempNodeForFaterNode=node;
		if(tempNodeForFaterNode.equals(tree.rootNode)){
			
		}else{
			while(!(tempNodeForFaterNode.equals(tree.rootNode))){
				tempForFatherNode=" -- <a href=\""+tempNodeForFaterNode.ID+"column.html\">"+tempNodeForFaterNode.name+"</a>"+tempForFatherNode;
				tempForFatherNodeAndLinkOutToNcbi=new String("Go to Taxonomy Browser:&nbsp;&nbsp;<a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target="+ tempNodeForFaterNode.name +"\">"+tempNodeForFaterNode.name+"</a>");
				tempNodeForFaterNode=tempNodeForFaterNode.fatherNode;
			}
		}
		smallColumnChartStringBuffer.append(tempForFatherNode+"<p>&nbsp;</p><p>&nbsp;</p>"+tempForFatherNodeAndLinkOutToNcbi+"<p>&nbsp;</p><p>&nbsp;</p></body>\n</html>\n");
		
		PrintStream smallColumn;
		FileOutputStream smallColumnFileOutputStream=null;
		String fileName=outPutDir+File.separator+"smallSvg"+File.separator+node.ID+"column.html";
		File backupFile=new File(fileName);
		try {
			smallColumnFileOutputStream =new FileOutputStream(backupFile);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot output the column chart file, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
		smallColumn=new PrintStream(smallColumnFileOutputStream);
		smallColumn.print(smallColumnChartStringBuffer);
		
		if(node.subNodes.size()>0){
			for(MetaSeeNode i:node.subNodes){
				drawSmallColumn(i,outPutDir);
			}
		}
	}	
}
