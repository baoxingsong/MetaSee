package org.metasee.www;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * built tree structure from file exported from the result of Parallel-Meta
 */
public class MetaSeeBuiltTreeFromParalleMeta {
	/**
	 * add node to a tree
	 * @param filePath the path of input result of Parallel-Meta
	 * @param rootNode the root node of tree
	 * 
	 */
	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){//�������νṹ����¼�Ǹ��ڵ�Ϊ���ڵ㣬Ȼ��ͨ��һ��һ���Ľṹ�ﵽ�洢���νṹ��Ŀ��
		File inPutFile=new File(filePath);
		MetaSeeTree.databaSetaName.add(inPutFile.getName());
		readTheNodeOfThisFile(filePath);
	}
	/**
	 * Begin to add node
	 * @param filePath the path of input result of Parallel-Meta
	 */
	public static void readTheNodeOfThisFile(String filePath){
		BufferedReader parallelMeta = null;
		String line;
		Pattern nodeNamePattern=Pattern.compile("(\\w+);");//�ڵ㿪ʼ
		try {
			parallelMeta = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			System.out.println("Cannot open the input file(s), check it please!");
			e.printStackTrace();
			System.exit(1);
		}
		try {
			while((line=parallelMeta.readLine())!=null){
				Matcher nodeNameMatcher=nodeNamePattern.matcher(line);
				MetaSeeNode currentNode=MetaSeeTree.rootNode;
				
				while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){//set root which is not in this file
					currentNode.counts.add(0);
				}
				currentNode.counts.set((currentNode.counts.size()-1),(currentNode.counts.get(currentNode.counts.size()-1)+1));
				
				
				while(nodeNameMatcher.find()){
					if( currentNode.getSubNodeByName(nodeNameMatcher.group(1)) !=null){
						
						currentNode=currentNode.getSubNodeByName(nodeNameMatcher.group(1));
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size())){
							currentNode.counts.add(0);
						}
						currentNode.counts.set((currentNode.counts.size()-1),(currentNode.counts.get(currentNode.counts.size()-1)+1));
																		
					}else{
						MetaSeeNode tempNode=new MetaSeeNode(nodeNameMatcher.group(1));
						tempNode.fatherNode=currentNode;
						currentNode.addSubNode(tempNode);
						currentNode=tempNode;
						while(currentNode.counts.size()<(MetaSeeTree.databaSetaName.size()-1)){
							currentNode.counts.add(0);
						}
						currentNode.counts.add(1);						
					}
				}
			}
		} catch (IOException e) {
			System.out.println("Something error happend when read the input file.");
			e.printStackTrace();
			System.exit(1);
		}
	}
}
