package org.metasee.www;

import java.io.File;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/**
 * @author SongBaoxing
 * @contact songbx@qibebt.ac.cn
 * built tree structure from file with XML format
 */
public class MetaSeeBuiltTreeFromXml {

	/**
	 * add node to a tree
	 * @param filePath the path of input file with XML format
	 * @param rootNode the root node of tree
	 * 
	 */

	public static void MultipleFileTree(String filePath, MetaSeeNode rootNode){
		int datasetNumberOfThisFile=0; //int to store the number of sample of this file
		
		SAXReader reader=new SAXReader();
		Document ducument=null;
		try {
			ducument = reader.read(new File(filePath));
		} catch (DocumentException e) {
			System.out.println("Cannot open the input file(s), check it please!");
			e.printStackTrace();
			System.exit(1);
		}
		Element rootElement=ducument.getRootElement();
		for( Iterator<Element> i=rootElement.elementIterator();i.hasNext();){
			Element element=i.next();
			if(element.getName().equals("datasets")){				
				datasetNumberOfThisFile=readTheNameOfSample(element);
			}
		}
		
		for( Iterator<Element> i=rootElement.elementIterator();i.hasNext();){
			Element element=i.next();
			if(element.getName().equals("node")){				
				readTheNodeOfThisFile(element,datasetNumberOfThisFile,rootNode);
			}
		}
	}
	
	/**
	 * read the name of samples
	 * @param element the element of data sets part of input file with XML format
	 * @return the number of sample in this file
	 */
	public static int readTheNameOfSample(Element element){
		int datasetNumberOfThisFile=0;
		for( Iterator<Element> i=element.elementIterator();i.hasNext();){
			Element datasetNameElement=i.next();
			MetaSeeTree.databaSetaName.add(datasetNameElement.getStringValue());
			datasetNumberOfThisFile++;
		}
		return datasetNumberOfThisFile;
	}
	/**
	 * read the content of nodes
	 * @param element the element of node part of input file with XML format
	 * @param datasetNumberOfThisFile the number of sample in this file
	 * @param fatherNode the father node of node to be read
	 */
	public static void readTheNodeOfThisFile(Element element,int datasetNumberOfThisFile, MetaSeeNode fatherNode){
		int currentNumberOfThisFile=0;
		MetaSeeNode tempNewNode=null;
		
		if(fatherNode.getSubNodeByName(element.attributeValue("name")) == null){
			tempNewNode=new MetaSeeNode(element.attributeValue("name"));
			fatherNode.addSubNode(tempNewNode);
			tempNewNode.fatherNode=fatherNode;
			//if we create a new node, we should declare that the number of this node of other sample is zero 
			for(int countExistedSample=1;countExistedSample<=MetaSeeTree.databaSetaName.size()-datasetNumberOfThisFile;countExistedSample++){
				tempNewNode.addSample(0);
			}
		}else{
			tempNewNode=fatherNode.getSubNodeByName(element.attributeValue("name"));
		}
		
		
		for( Iterator<Element> i=element.elementIterator();i.hasNext();){
			Element subNodeElement=i.next();
			
			if(subNodeElement.getName().equals("count")){
				int countOfThisNode=0;
				String countOfThisNodeString=new String();
				for( Iterator<Element> j=subNodeElement.elementIterator();j.hasNext();){
					Element subNodeElementCountVal=j.next();
					countOfThisNodeString=subNodeElementCountVal.getTextTrim();
					if(countOfThisNodeString == null || countOfThisNodeString.equals("")){
						countOfThisNode=0;
					}else{
						countOfThisNode=Integer.parseInt(countOfThisNodeString);
					}
					tempNewNode.addSample(countOfThisNode);
					currentNumberOfThisFile++;
				}
				if(currentNumberOfThisFile<datasetNumberOfThisFile){
					for(int shortOfCurrentNode=1;shortOfCurrentNode<=datasetNumberOfThisFile-currentNumberOfThisFile;shortOfCurrentNode++){
						tempNewNode.addSample(0);
					}
				}
			}
			
			if(subNodeElement.getName().equals("node")){//recursion to backward node section				
				readTheNodeOfThisFile(subNodeElement,datasetNumberOfThisFile,tempNewNode);
			}
		}
	}
	
}
