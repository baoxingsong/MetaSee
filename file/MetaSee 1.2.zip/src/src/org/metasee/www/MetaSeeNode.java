package org.metasee.www;
import java.util.ArrayList;
import java.util.List;

/**
 * node of tree structure
 * @author SongBaoxing
 *
 */
public class MetaSeeNode {
	/**
	 * the name of node
	 */
	String name;
	/**
	 * the count information of node
	 */
	List<Integer> counts=new ArrayList<Integer>();
	/**
	 * the subnode of this node
	 */
	List<MetaSeeNode> subNodes=new ArrayList<MetaSeeNode>();
	/**
	 * the count of leaft of the subnodes and subsubnodes .. of this node
	 */
	int countOfLeaft=0;
	/**
	 * the x-axis of this node in global view
	 */
	double positionX;
	/**
	 * the y-axis of this node in global view
	 */
	double positionY;
	/**
	 * the id of this node
	 */
	int ID;
	/**
	 * the height information of this node in global view
	 */
	List<Double> verticalBarPoint=new ArrayList<Double>();
	/**
	 * the father node of this node
	 */
	MetaSeeNode fatherNode=null;
	/**
	 * set the node of this node
	 * @param name
	 */
	public MetaSeeNode(String name){
		this.name=name;
	}
	/**
	 * add count information of this node
	 * @param count
	 */
	public void addSample(Integer count){
		this.counts.add(count);
	}
	/**
	 * add subnode to this node
	 * @param node
	 */
	public void addSubNode(MetaSeeNode node){
		try {
			this.subNodes.add(node);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("There seems more val in node than dataset in datasets");
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	/**
	 * has sub node or not (is this node a leaft?)
	 * @return
	 */
	public boolean hasSubNode(){
		if(this.subNodes.size() >= 1){
			return true;
		}
		else{
			return false;
		}
	}
	/**
	 * input a String and look whether there are a subnode, of this node, in this name 
	 * @param subNodeName
	 * @return
	 */
	public MetaSeeNode getSubNodeByName(String subNodeName){
		for(MetaSeeNode i:this.subNodes){
			if(i.name.equals(subNodeName)){
				return i;
			}
		}
		return null;
	}
	/**
	 * get the maximum one of all the subnodes of thisnode
	 * @return the height of maximum subnode
	 */
	public double getMaxVerticalBarPoint(){
		double maxVerticalBarPoint=0;
		for(MetaSeeNode i: subNodes){
			if(maxVerticalBarPoint < i.positionY){
				maxVerticalBarPoint =i.positionY;
			}
		}
		return maxVerticalBarPoint;
	}
	/**
	 * get the minimum one of all the subnodes of thisnode
	 * @return the height of minimumsubnode
	 */
	public double getMinVerticalBarPoint(){
		double minVerticalBarPoint=500000000.0;
		for(MetaSeeNode i: subNodes){
			if(minVerticalBarPoint >i.positionY){
				minVerticalBarPoint =i.positionY;
			}
		}
		return minVerticalBarPoint;
	}
}
