package org.metasee.www;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.swing.filechooser.FileSystemView;

public class ZipFile {

	 public void run(String outPutDir){
         try {
			zipFile(outPutDir+File.separator+"smallSvg", "globleView.svg",outPutDir+File.separator+"smallSvg"+File.separator+"globleView.zip");
		} catch (FileNotFoundException e) {
			System.out.println("There are something error happend when outpur the Global zip file, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}  //
    }
    
    /**
     * @param baseDirName 
     * @param fileName
     * @param targerFileName
     * @throws FileNotFoundException 
     */
    public static void zipFile(String baseDirName, String fileName,
            String targerFileName) throws FileNotFoundException{
        if (baseDirName == null || "".equals(baseDirName)) {
            return;
        }
        File baseDir = new File(baseDirName);
        
        if (!baseDir.exists() || !baseDir.isDirectory()) {
            return;
        }

        String baseDirPath = baseDir.getAbsolutePath();

        File targerFile = new File(targerFileName);

        ZipOutputStream out= new ZipOutputStream(new FileOutputStream(
			        targerFile));
		

        File file = new File(baseDir, fileName);

        if (file.isFile()) {
            fileToZip(baseDirPath, file, out);
        } else {
            dirToZip(baseDirPath, file, out);
        }
        try {
			out.close();
		} catch (IOException e) {
			System.out.println("There are something error happend when outpur the Global zip file, check it please, or you can contact songbaoxing168@163.com for help!");
			e.printStackTrace();
			System.exit(1);
		}
    }

    private static void dirToZip(String baseDirPath, File dir,
            ZipOutputStream out){
        if (!dir.isDirectory()) {
            return;
        }

        File[] files = dir.listFiles();

        if (files.length == 0) {
            ZipEntry entry = new ZipEntry(getEntryName(baseDirPath, dir));

            try {
                out.putNextEntry(entry);
                out.closeEntry();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                fileToZip(baseDirPath, files[i], out);
            } else {
                dirToZip(baseDirPath, files[i], out);
            }

        }

    }

    private static void fileToZip(String baseDirPath, File file,
            ZipOutputStream out){
        FileInputStream in = null;
        ZipEntry entry = null;

        byte[] buffer = new byte[4096];
        int bytes_read;

        if (file.isFile()) {
            try {
                in = new FileInputStream(file);
                
                entry = new ZipEntry(getEntryName(baseDirPath, file));
                out.putNextEntry(entry);
                
                while ((bytes_read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytes_read);
                }
                out.closeEntry();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                // �ر����������
                if (out != null) {
                    try {
						out.closeEntry();
					} catch (IOException e) {
						System.out.println("There are something error happend when outpur the Global zip file, check it please, or you can contact songbaoxing168@163.com for help!");
						e.printStackTrace();
						System.exit(1);
					}
                }

                if (in != null) {
                    try {
						in.close();
					} catch (IOException e) {
						System.out.println("There are something error happend when outpur the Global zip file, check it please, or you can contact songbaoxing168@163.com for help!");
						e.printStackTrace();
						System.exit(1);
					}
                }
            }
        }
    }

    private static String getEntryName(String baseDirPath, File file) {
        if (!baseDirPath.endsWith(File.separator)) {
            baseDirPath = baseDirPath + File.separator;
        }

        String filePath = file.getAbsolutePath();
        if (file.isDirectory()) {
            filePath = filePath + "/";
        }

        int index = filePath.indexOf(baseDirPath);

        return filePath.substring(index + baseDirPath.length());
    }

}
