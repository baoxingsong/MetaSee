package org.metasee.www;

import static org.junit.Assert.*;

import org.junit.Test;

public class MetaSeeTest {

	@Test
	public void testMain() {
		String[] args={"-i","C:\\Users\\Administrator\\Desktop\\plos one metasee\\metasee1.1\\metasee_multiple.xml","-o","test","-f","metasee"};
		MetaSee.main(args);
	}

	@Test
	public void testProduceTree() {
		fail("Not yet implemented");
	}

	@Test
	public void testProduce() {
		fail("Not yet implemented");
	}

}
