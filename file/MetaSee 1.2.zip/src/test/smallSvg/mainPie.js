var labelType, useGradients, nativeTextSupport, animate;
(function() {
var ua = navigator.userAgent,
iStuff = ua.match(/iPhone/i) || ua.match(/iPad/i),
 typeOfCanvas = typeof HTMLCanvasElement,
nativeCanvasSupport = (typeOfCanvas == 'object' || typeOfCanvas == 'function'),
textSupport = nativeCanvasSupport
 && (typeof document.createElement('canvas').getContext('2d').fillText == 'function');
labelType = (!nativeCanvasSupport || (textSupport && !iStuff))? 'Native' : 'HTML';
nativeTextSupport = labelType == 'Native';
useGradients = nativeCanvasSupport;
animate = !(iStuff || !nativeCanvasSupport);
})();
var Log = {
 elem: false,write: function(text){if (!this.elem)this.elem = document.getElementById('log');this.elem.innerHTML = text;this.elem.style.left = (500 - this.elem.offsetWidth / 2) + 'px';  }};var depth=6;

var json1 ={
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br />Sulfolobaceae<br/><a href=\"5pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"5column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales/Sulfolobaceae", 
"name": "Sulfolobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br/><a href=\"4pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"4column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales", 
"name": "Sulfolobales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br />Thermofilum<br/><a href=\"8pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"8column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilum\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae/Thermofilum", 
"name": "Thermofilum"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br/><a href=\"7pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"7column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae", 
"name": "Thermofilaceae"
},
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br />Thermocladium<br/><a href=\"10pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"10column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermocladium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae/Thermocladium", 
"name": "Thermocladium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br/><a href=\"9pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"9column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae", 
"name": "Thermoproteaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br/><a href=\"6pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"6column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales", 
"name": "Thermoproteales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Staphylothermus<br/><a href=\"13pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"13column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Staphylothermus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Staphylothermus", 
"name": "Staphylothermus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Ignisphaera<br/><a href=\"14pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"14column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Ignisphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Ignisphaera", 
"name": "Ignisphaera"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Desulfurococcus<br/><a href=\"15pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"15column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Desulfurococcus", 
"name": "Desulfurococcus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br/><a href=\"12pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"12column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae", 
"name": "Desulfurococcaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br/><a href=\"11pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"11column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales", 
"name": "Desulfurococcales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br/><a href=\"3pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"3column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoprotei\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei", 
"name": "Thermoprotei"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br/><a href=\"2pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"2column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Crenarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#00ff00",
 "size": 1
},
"id": "Archaea/Crenarchaeota", 
"name": "Crenarchaeota"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br />Methanomicrobium<br/><a href=\"20pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"20column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#7f8000",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae/Methanomicrobium", 
"name": "Methanomicrobium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br/><a href=\"19pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"19column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae", 
"name": "Methanomicrobiaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br/><a href=\"18pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"18column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales", 
"name": "Methanomicrobiales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br/><a href=\"17pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"17column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobia\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanomicrobia", 
"name": "Methanomicrobia"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronomonas<br/><a href=\"24pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"24column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#ff0000",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronomonas", 
"name": "Natronomonas"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronobacterium<br/><a href=\"25pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"25column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronobacterium", 
"name": "Natronobacterium"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Haladaptatus<br/><a href=\"26pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"26column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Haladaptatus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#ff0000",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Haladaptatus", 
"name": "Haladaptatus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Halobacterium<br/><a href=\"27pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"27column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#ff0000",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Halobacterium", 
"name": "Halobacterium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br/><a href=\"23pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"23column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 6,
"$color": "#ff0000",
 "size": 6
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae", 
"name": "Halobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br/><a href=\"22pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"22column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 6,
"$color": "#ff0000",
 "size": 6
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales", 
"name": "Halobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br/><a href=\"21pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"21column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 6,
"$color": "#ff0000",
 "size": 6
},
"id": "Archaea/Euryarchaeota/Halobacteria", 
"name": "Halobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br />Methanosphaera<br/><a href=\"31pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"31column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanosphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae/Methanosphaera", 
"name": "Methanosphaera"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br/><a href=\"30pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"30column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae", 
"name": "Methanobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br/><a href=\"29pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"29column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales", 
"name": "Methanobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br/><a href=\"28pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"28column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria", 
"name": "Methanobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br />Geoglobus<br/><a href=\"35pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"35column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Geoglobus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae/Geoglobus", 
"name": "Geoglobus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br/><a href=\"34pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"34column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae", 
"name": "Archaeoglobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br/><a href=\"33pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"33column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales", 
"name": "Archaeoglobales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br/><a href=\"32pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"32column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobi\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi", 
"name": "Archaeoglobi"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br />Methanopyrus<br/><a href=\"39pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"39column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae/Methanopyrus", 
"name": "Methanopyrus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br/><a href=\"38pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"38column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyraceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae", 
"name": "Methanopyraceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br/><a href=\"37pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"37column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales", 
"name": "Methanopyrales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br/><a href=\"36pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"36column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyri\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri", 
"name": "Methanopyri"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br />Thermogymnomonas<br/><a href=\"43pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"43column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermogymnomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis/Thermogymnomonas", 
"name": "Thermogymnomonas"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br/><a href=\"42pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"42column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales_incertae_sedis\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis", 
"name": "Thermoplasmatales_incertae_sedis"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br/><a href=\"41pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"41column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales", 
"name": "Thermoplasmatales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br/><a href=\"40pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"40column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmata\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata", 
"name": "Thermoplasmata"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br/><a href=\"16pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"16column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Euryarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#ff0000",
 "size": 7
},
"id": "Archaea/Euryarchaeota", 
"name": "Euryarchaeota"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br/><a href=\"1pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"1column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaea\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=0\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 8,
"$color": "#ff0000",
 "size": 8
},
"id": "Archaea", 
"name": "Archaea"
};

var json2 ={
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br />Sulfolobaceae<br/><a href=\"5pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"5column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales/Sulfolobaceae", 
"name": "Sulfolobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br/><a href=\"4pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"4column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales", 
"name": "Sulfolobales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br />Thermofilum<br/><a href=\"8pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"8column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilum\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae/Thermofilum", 
"name": "Thermofilum"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br/><a href=\"7pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"7column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae", 
"name": "Thermofilaceae"
},
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br />Thermocladium<br/><a href=\"10pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"10column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermocladium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 3,
"days": 3,
"$color": "#ff0000",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae/Thermocladium", 
"name": "Thermocladium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br/><a href=\"9pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"9column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 3,
"$color": "#ff0000",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae", 
"name": "Thermoproteaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br/><a href=\"6pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"6column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 3,
"$color": "#ff0000",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales", 
"name": "Thermoproteales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Staphylothermus<br/><a href=\"13pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"13column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Staphylothermus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Staphylothermus", 
"name": "Staphylothermus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Ignisphaera<br/><a href=\"14pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"14column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Ignisphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Ignisphaera", 
"name": "Ignisphaera"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Desulfurococcus<br/><a href=\"15pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"15column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Desulfurococcus", 
"name": "Desulfurococcus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br/><a href=\"12pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"12column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#aa5500",
 "size": 2
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae", 
"name": "Desulfurococcaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br/><a href=\"11pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"11column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#aa5500",
 "size": 2
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales", 
"name": "Desulfurococcales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br/><a href=\"3pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"3column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoprotei\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#ff0000",
 "size": 5
},
"id": "Archaea/Crenarchaeota/Thermoprotei", 
"name": "Thermoprotei"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br/><a href=\"2pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"2column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Crenarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#ff0000",
 "size": 5
},
"id": "Archaea/Crenarchaeota", 
"name": "Crenarchaeota"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br />Methanomicrobium<br/><a href=\"20pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"20column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae/Methanomicrobium", 
"name": "Methanomicrobium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br/><a href=\"19pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"19column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae", 
"name": "Methanomicrobiaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br/><a href=\"18pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"18column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales", 
"name": "Methanomicrobiales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br/><a href=\"17pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"17column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobia\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia", 
"name": "Methanomicrobia"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronomonas<br/><a href=\"24pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"24column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronomonas", 
"name": "Natronomonas"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronobacterium<br/><a href=\"25pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"25column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronobacterium", 
"name": "Natronobacterium"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Haladaptatus<br/><a href=\"26pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"26column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Haladaptatus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#aa5500",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Haladaptatus", 
"name": "Haladaptatus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Halobacterium<br/><a href=\"27pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"27column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Halobacterium", 
"name": "Halobacterium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br/><a href=\"23pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"23column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#aa5500",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae", 
"name": "Halobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br/><a href=\"22pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"22column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#aa5500",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales", 
"name": "Halobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br/><a href=\"21pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"21column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#669900",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria", 
"name": "Halobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br />Methanosphaera<br/><a href=\"31pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"31column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanosphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae/Methanosphaera", 
"name": "Methanosphaera"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br/><a href=\"30pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"30column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae", 
"name": "Methanobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br/><a href=\"29pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"29column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales", 
"name": "Methanobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br/><a href=\"28pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"28column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria", 
"name": "Methanobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br />Geoglobus<br/><a href=\"35pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"35column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Geoglobus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae/Geoglobus", 
"name": "Geoglobus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br/><a href=\"34pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"34column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae", 
"name": "Archaeoglobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br/><a href=\"33pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"33column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales", 
"name": "Archaeoglobales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br/><a href=\"32pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"32column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobi\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#33cc00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Archaeoglobi", 
"name": "Archaeoglobi"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br />Methanopyrus<br/><a href=\"39pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"39column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae/Methanopyrus", 
"name": "Methanopyrus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br/><a href=\"38pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"38column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyraceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae", 
"name": "Methanopyraceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br/><a href=\"37pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"37column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales", 
"name": "Methanopyrales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br/><a href=\"36pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"36column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyri\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#33cc00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Methanopyri", 
"name": "Methanopyri"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br />Thermogymnomonas<br/><a href=\"43pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"43column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermogymnomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis/Thermogymnomonas", 
"name": "Thermogymnomonas"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br/><a href=\"42pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"42column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales_incertae_sedis\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis", 
"name": "Thermoplasmatales_incertae_sedis"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br/><a href=\"41pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"41column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#55aa00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales", 
"name": "Thermoplasmatales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br/><a href=\"40pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"40column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmata\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#33cc00",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Thermoplasmata", 
"name": "Thermoplasmata"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br/><a href=\"16pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"16column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Euryarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#ff0000",
 "size": 5
},
"id": "Archaea/Euryarchaeota", 
"name": "Euryarchaeota"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br/><a href=\"1pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"1column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaea\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=1\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 10,
"$color": "#ff0000",
 "size": 10
},
"id": "Archaea", 
"name": "Archaea"
};

var json3 ={
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br />Sulfolobaceae<br/><a href=\"5pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"5column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales/Sulfolobaceae", 
"name": "Sulfolobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br/><a href=\"4pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"4column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales", 
"name": "Sulfolobales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br />Thermofilum<br/><a href=\"8pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"8column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilum\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae/Thermofilum", 
"name": "Thermofilum"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br/><a href=\"7pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"7column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae", 
"name": "Thermofilaceae"
},
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br />Thermocladium<br/><a href=\"10pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"10column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermocladium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae/Thermocladium", 
"name": "Thermocladium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br/><a href=\"9pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"9column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#24db00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae", 
"name": "Thermoproteaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br/><a href=\"6pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"6column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#24db00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales", 
"name": "Thermoproteales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Staphylothermus<br/><a href=\"13pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"13column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Staphylothermus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Staphylothermus", 
"name": "Staphylothermus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Ignisphaera<br/><a href=\"14pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"14column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Ignisphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Ignisphaera", 
"name": "Ignisphaera"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Desulfurococcus<br/><a href=\"15pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"15column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Desulfurococcus", 
"name": "Desulfurococcus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br/><a href=\"12pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"12column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#24db00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae", 
"name": "Desulfurococcaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br/><a href=\"11pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"11column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 1,
"$color": "#24db00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales", 
"name": "Desulfurococcales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br/><a href=\"3pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"3column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoprotei\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#48b700",
 "size": 2
},
"id": "Archaea/Crenarchaeota/Thermoprotei", 
"name": "Thermoprotei"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br/><a href=\"2pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"2column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Crenarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#00ff00",
 "size": 2
},
"id": "Archaea/Crenarchaeota", 
"name": "Crenarchaeota"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br />Methanomicrobium<br/><a href=\"20pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"20column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae/Methanomicrobium", 
"name": "Methanomicrobium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br/><a href=\"19pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"19column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae", 
"name": "Methanomicrobiaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br/><a href=\"18pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"18column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales", 
"name": "Methanomicrobiales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br/><a href=\"17pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"17column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobia\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia", 
"name": "Methanomicrobia"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronomonas<br/><a href=\"24pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"24column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronomonas", 
"name": "Natronomonas"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronobacterium<br/><a href=\"25pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"25column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#2ad500",
 "size": 1
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronobacterium", 
"name": "Natronobacterium"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Haladaptatus<br/><a href=\"26pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"26column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Haladaptatus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 6,
"days": 6,
"$color": "#ff0000",
 "size": 6
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Haladaptatus", 
"name": "Haladaptatus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Halobacterium<br/><a href=\"27pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"27column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Halobacterium", 
"name": "Halobacterium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br/><a href=\"23pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"23column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#ff0000",
 "size": 7
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae", 
"name": "Halobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br/><a href=\"22pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"22column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#ff0000",
 "size": 7
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales", 
"name": "Halobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br/><a href=\"21pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"21column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#ff0000",
 "size": 7
},
"id": "Archaea/Euryarchaeota/Halobacteria", 
"name": "Halobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br />Methanosphaera<br/><a href=\"31pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"31column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanosphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae/Methanosphaera", 
"name": "Methanosphaera"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br/><a href=\"30pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"30column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae", 
"name": "Methanobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br/><a href=\"29pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"29column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales", 
"name": "Methanobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br/><a href=\"28pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"28column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanobacteria", 
"name": "Methanobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br />Geoglobus<br/><a href=\"35pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"35column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Geoglobus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae/Geoglobus", 
"name": "Geoglobus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br/><a href=\"34pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"34column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae", 
"name": "Archaeoglobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br/><a href=\"33pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"33column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales", 
"name": "Archaeoglobales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br/><a href=\"32pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"32column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobi\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi", 
"name": "Archaeoglobi"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br />Methanopyrus<br/><a href=\"39pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"39column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae/Methanopyrus", 
"name": "Methanopyrus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br/><a href=\"38pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"38column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyraceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae", 
"name": "Methanopyraceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br/><a href=\"37pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"37column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales", 
"name": "Methanopyrales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br/><a href=\"36pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"36column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyri\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanopyri", 
"name": "Methanopyri"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br />Thermogymnomonas<br/><a href=\"43pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"43column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermogymnomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis/Thermogymnomonas", 
"name": "Thermogymnomonas"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br/><a href=\"42pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"42column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales_incertae_sedis\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis", 
"name": "Thermoplasmatales_incertae_sedis"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br/><a href=\"41pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"41column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales", 
"name": "Thermoplasmatales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br/><a href=\"40pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"40column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmata\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata", 
"name": "Thermoplasmata"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br/><a href=\"16pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"16column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Euryarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#ff0000",
 "size": 7
},
"id": "Archaea/Euryarchaeota", 
"name": "Euryarchaeota"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br/><a href=\"1pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"1column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaea\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=2\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 9,
"$color": "#ff0000",
 "size": 9
},
"id": "Archaea", 
"name": "Archaea"
};

var json4 ={
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br />Sulfolobaceae<br/><a href=\"5pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"5column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=4&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales/Sulfolobaceae", 
"name": "Sulfolobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Sulfolobales<br/><a href=\"4pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"4column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Sulfolobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=3&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Sulfolobales", 
"name": "Sulfolobales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br />Thermofilum<br/><a href=\"8pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"8column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilum\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=7&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 3,
"days": 3,
"$color": "#3ac500",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae/Thermofilum", 
"name": "Thermofilum"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermofilaceae<br/><a href=\"7pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"7column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermofilaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=6&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 3,
"$color": "#33cc00",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermofilaceae", 
"name": "Thermofilaceae"
},
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br />Thermocladium<br/><a href=\"10pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"10column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermocladium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=9&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae/Thermocladium", 
"name": "Thermocladium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br />Thermoproteaceae<br/><a href=\"9pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"9column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=8&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales/Thermoproteaceae", 
"name": "Thermoproteaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Thermoproteales<br/><a href=\"6pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"6column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoproteales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=5&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 3,
"$color": "#33cc00",
 "size": 3
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Thermoproteales", 
"name": "Thermoproteales"
},
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Staphylothermus<br/><a href=\"13pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"13column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Staphylothermus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=12&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#13ec00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Staphylothermus", 
"name": "Staphylothermus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Ignisphaera<br/><a href=\"14pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"14column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Ignisphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=13&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#27d800",
 "size": 2
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Ignisphaera", 
"name": "Ignisphaera"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br />Desulfurococcus<br/><a href=\"15pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"15column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=14&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1,
"days": 1,
"$color": "#13ec00",
 "size": 1
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae/Desulfurococcus", 
"name": "Desulfurococcus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br />Desulfurococcaceae<br/><a href=\"12pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"12column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=11&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 4,
"$color": "#44bb00",
 "size": 4
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales/Desulfurococcaceae", 
"name": "Desulfurococcaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br />Desulfurococcales<br/><a href=\"11pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"11column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Desulfurococcales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=10&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 4,
"$color": "#44bb00",
 "size": 4
},
"id": "Archaea/Crenarchaeota/Thermoprotei/Desulfurococcales", 
"name": "Desulfurococcales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br />Thermoprotei<br/><a href=\"3pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"3column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoprotei\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=2&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#778800",
 "size": 7
},
"id": "Archaea/Crenarchaeota/Thermoprotei", 
"name": "Thermoprotei"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Crenarchaeota<br/><a href=\"2pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"2column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Crenarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=1&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 7,
"$color": "#00ff00",
 "size": 7
},
"id": "Archaea/Crenarchaeota", 
"name": "Crenarchaeota"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br />Methanomicrobium<br/><a href=\"20pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"20column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=19&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae/Methanomicrobium", 
"name": "Methanomicrobium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br />Methanomicrobiaceae<br/><a href=\"19pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"19column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=18&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales/Methanomicrobiaceae", 
"name": "Methanomicrobiaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br />Methanomicrobiales<br/><a href=\"18pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"18column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobiales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=17&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia/Methanomicrobiales", 
"name": "Methanomicrobiales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanomicrobia<br/><a href=\"17pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"17column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanomicrobia\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=16&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Methanomicrobia", 
"name": "Methanomicrobia"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronomonas<br/><a href=\"24pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"24column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=23&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#27d800",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronomonas", 
"name": "Natronomonas"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Natronobacterium<br/><a href=\"25pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"25column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Natronobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=24&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Natronobacterium", 
"name": "Natronobacterium"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Haladaptatus<br/><a href=\"26pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"26column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Haladaptatus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=25&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 13,
"days": 13,
"$color": "#ff0000",
 "size": 13
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Haladaptatus", 
"name": "Haladaptatus"
},
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br />Halobacterium<br/><a href=\"27pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"27column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacterium\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=26&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae/Halobacterium", 
"name": "Halobacterium"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br />Halobacteriaceae<br/><a href=\"23pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"23column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=22&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 15,
"$color": "#ff0000",
 "size": 15
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales/Halobacteriaceae", 
"name": "Halobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br />Halobacteriales<br/><a href=\"22pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"22column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=21&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 15,
"$color": "#ff0000",
 "size": 15
},
"id": "Archaea/Euryarchaeota/Halobacteria/Halobacteriales", 
"name": "Halobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Halobacteria<br/><a href=\"21pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"21column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Halobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=20&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 15,
"$color": "#ff0000",
 "size": 15
},
"id": "Archaea/Euryarchaeota/Halobacteria", 
"name": "Halobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br />Methanosphaera<br/><a href=\"31pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"31column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanosphaera\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=30&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 5,
"days": 5,
"$color": "#629d00",
 "size": 5
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae/Methanosphaera", 
"name": "Methanosphaera"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br />Methanobacteriaceae<br/><a href=\"30pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"30column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=29&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#55aa00",
 "size": 5
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales/Methanobacteriaceae", 
"name": "Methanobacteriaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br />Methanobacteriales<br/><a href=\"29pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"29column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteriales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=28&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#55aa00",
 "size": 5
},
"id": "Archaea/Euryarchaeota/Methanobacteria/Methanobacteriales", 
"name": "Methanobacteriales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanobacteria<br/><a href=\"28pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"28column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanobacteria\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=27&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 5,
"$color": "#55aa00",
 "size": 5
},
"id": "Archaea/Euryarchaeota/Methanobacteria", 
"name": "Methanobacteria"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br />Geoglobus<br/><a href=\"35pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"35column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Geoglobus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=34&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae/Geoglobus", 
"name": "Geoglobus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br />Archaeoglobaceae<br/><a href=\"34pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"34column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobaceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=33&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales/Archaeoglobaceae", 
"name": "Archaeoglobaceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br />Archaeoglobales<br/><a href=\"33pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"33column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=32&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi/Archaeoglobales", 
"name": "Archaeoglobales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Archaeoglobi<br/><a href=\"32pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"32column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaeoglobi\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=31&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Archaeoglobi", 
"name": "Archaeoglobi"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br />Methanopyrus<br/><a href=\"39pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"39column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrus\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=38&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 2,
"days": 2,
"$color": "#27d800",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae/Methanopyrus", 
"name": "Methanopyrus"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br />Methanopyraceae<br/><a href=\"38pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"38column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyraceae\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=37&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#22dd00",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales/Methanopyraceae", 
"name": "Methanopyraceae"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br />Methanopyrales<br/><a href=\"37pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"37column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyrales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=36&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#22dd00",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Methanopyri/Methanopyrales", 
"name": "Methanopyrales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Methanopyri<br/><a href=\"36pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"36column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Methanopyri\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=35&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 2,
"$color": "#22dd00",
 "size": 2
},
"id": "Archaea/Euryarchaeota/Methanopyri", 
"name": "Methanopyri"
},
{
"children": [
{
"children": [
{
"children": [
{
"children": [],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br />Thermogymnomonas<br/><a href=\"43pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"43column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermogymnomonas\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=42&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 0,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis/Thermogymnomonas", 
"name": "Thermogymnomonas"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br />Thermoplasmatales_incertae_sedis<br/><a href=\"42pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"42column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales_incertae_sedis\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=41&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales/Thermoplasmatales_incertae_sedis", 
"name": "Thermoplasmatales_incertae_sedis"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br />Thermoplasmatales<br/><a href=\"41pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"41column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmatales\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=40&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata/Thermoplasmatales", 
"name": "Thermoplasmatales"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br />Thermoplasmata<br/><a href=\"40pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"40column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Thermoplasmata\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=39&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 0,
"$color": "#00ff00",
 "size": 0
},
"id": "Archaea/Euryarchaeota/Thermoplasmata", 
"name": "Thermoplasmata"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br />Euryarchaeota<br/><a href=\"16pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"16column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Euryarchaeota\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=15&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 22,
"$color": "#ff0000",
 "size": 22
},
"id": "Archaea/Euryarchaeota", 
"name": "Euryarchaeota"
},],
"data": {
"description":"<Strong>Classification:</Strong><br />Archaea<br/><a href=\"1pie.html\" target=\"main\">go to Taxa view(pie chart)</a><br/><a href=\"1column.html\" target=\"main\">go to Taxa view(bar chart)</a><br/><a href=\"globleView.svg\" target=\"main\">go to Globle View</a> <br/><a href=\"phylogeneticTree.html\" target=\"main\">go to Phylogenetic View</a><br /><a href=\"http://www.computationalbioenergy.org/web_service/parallel-meta_developing/visualization_redirect.cgi?target=Archaea\">go to Taxonomy Browser</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=0\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=1\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=2\" target=\"main\">go to Sample view</a><br/><a href=\"MetaSee_krona.html?node=0&dataset=3\" target=\"main\">go to Sample view</a>",
"$angularWidth": 1000,
"days": 29,
"$color": "#ff0000",
 "size": 29
},
"id": "Archaea", 
"name": "Archaea"
};function mainPie() {document.getElementById("infovis").innerHTML = "";if (document.getElementById("rb1").checked) {drawMainPie(json1);}else if (document.getElementById("rb2").checked) {drawMainPie(json2);}else if (document.getElementById("rb3").checked) {drawMainPie(json3);}else if (document.getElementById("rb4").checked) {drawMainPie(json4);}else {drawMainPie(json1);}}function drawMainPie(json){var json=json;var sb = new $jit.Sunburst({injectInto: 'infovis',levelDistance: 390.0/depth,Node: {overridable: true,type: useGradients? 'gradient-multipie' : 'multipie'},Label: {type: labelType},NodeStyles: {enable: true,type: 'Native',stylesClick: {'color': '#33dddd'},stylesHover: {'color': '#dd3333'}},Tips: {enable: true,onShow: function(tip, node) {var html = "<div class=\"tip-title\">" + node.name + "</div>"; var data = node.data;if("size" in data) {html += "<br /><b>Count:</b> " + data.size;}tip.innerHTML = html;}},Events: {enable: true,onClick: function(node) {if(!node) return;var html = "<h4>" + node.name + "</h4>", data = node.data;if("size" in data) {html += "<br /><br /><b>Count:</b> " + data.size;}if("description" in data) {html += "<br /><br /><b>ToolTips:</b><br /><pre>" + data.description + "</pre>";}$jit.id('inner-details').innerHTML = html;sb.tips.hide();sb.rotate(node, animate? 'animate' : 'replot', {duration: 1000,transition: $jit.Trans.Quart.easeInOut});}},onCreateLabel: function(domElement, node){var labels = sb.config.Label.type,aw = node.getData('angularWidth');if (labels === 'HTML' && (node._depth < 2 || aw > 2000)) {domElement.innerHTML = node.name;} else if (labels === 'SVG' && (node._depth < 2 || aw > 2000)) { domElement.firstChild.appendChild(document.createTextNode(node.name));}},onPlaceLabel: function(domElement, node){var labels = sb.config.Label.type;if (labels === 'SVG') {var fch = domElement.firstChild;var style = fch.style;style.display = '';style.cursor = 'pointer';style.fontSize = "0.8em";fch.setAttribute('fill', "#fff");} else if (labels === 'HTML') {var style = domElement.style; style.display = '';style.cursor = 'pointer';style.fontSize = "0.8em";style.color = "#ddd";var left = parseInt(style.left);var w = domElement.offsetWidth; style.left = (left - w / 2) + 'px';}}});sb.loadJSON(json);sb.refresh();}